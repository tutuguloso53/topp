import { db } from '@/lib/db';
import { CalendlyService } from './calendly-service';

export interface AppointmentData {
  patientName: string;
  patientEmail: string;
  patientPhone: string;
  appointmentDate: Date;
  startTime: Date;
  endTime: Date;
  notes?: string;
}

export interface AvailableSlot {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  isAvailable: boolean;
}

export class AppointmentService {
  private calendlyService: CalendlyService;

  constructor() {
    this.calendlyService = new CalendlyService();
  }

  async createAppointment(data: AppointmentData) {
    try {
      // Verificar se o horário está disponível
      const isAvailable = await this.checkSlotAvailability(
        data.appointmentDate,
        data.startTime,
        data.endTime
      );

      if (!isAvailable) {
        throw new Error('Este horário não está mais disponível');
      }

      // Criar o agendamento no banco de dados
      const appointment = await db.appointment.create({
        data: {
          patientName: data.patientName,
          patientEmail: data.patientEmail,
          patientPhone: data.patientPhone,
          appointmentDate: data.appointmentDate,
          startTime: data.startTime,
          endTime: data.endTime,
          status: 'PENDING',
          notes: data.notes,
        },
      });

      // Marcar o slot como não disponível
      await this.updateSlotAvailability(data.startTime, data.endTime, false);

      return appointment;
    } catch (error) {
      console.error('Erro ao criar agendamento:', error);
      throw error;
    }
  }

  async checkSlotAvailability(date: Date, startTime: Date, endTime: Date): Promise<boolean> {
    try {
      // Verificar se já existe um agendamento neste horário
      const existingAppointment = await db.appointment.findFirst({
        where: {
          appointmentDate: date,
          startTime: startTime,
          endTime: endTime,
          status: {
            in: ['PENDING', 'CONFIRMED'],
          },
        },
      });

      if (existingAppointment) {
        return false;
      }

      // Verificar se é um dia útil e não é feriado
      const dayOfWeek = date.getDay();
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      const isHoliday = await this.calendlyService.isHoliday(date);

      if (isWeekend || isHoliday) {
        return false;
      }

      // Verificar se está dentro do horário de funcionamento
      const hours = startTime.getHours();
      if (hours < 9 || hours >= 17) {
        return false;
      }

      return true;
    } catch (error) {
      console.error('Erro ao verificar disponibilidade:', error);
      return false;
    }
  }

  async updateSlotAvailability(startTime: Date, endTime: Date, isAvailable: boolean) {
    try {
      await db.availability.upsert({
        where: {
          date_startTime_endTime: {
            date: new Date(startTime.toDateString()),
            startTime: startTime,
            endTime: endTime,
          },
        },
        update: {
          isAvailable: isAvailable,
        },
        create: {
          date: new Date(startTime.toDateString()),
          startTime: startTime,
          endTime: endTime,
          isAvailable: isAvailable,
        },
      });
    } catch (error) {
      console.error('Erro ao atualizar disponibilidade:', error);
      throw error;
    }
  }

  async getAvailableSlots(daysAhead: number = 30): Promise<AvailableSlot[]> {
    try {
      // Obter slots disponíveis do Calendly
      const calendlySlots = await this.calendlyService.getAvailableAppointments(daysAhead);
      
      // Obter agendamentos existentes
      const existingAppointments = await db.appointment.findMany({
        where: {
          appointmentDate: {
            gte: new Date(),
            lte: new Date(Date.now() + daysAhead * 24 * 60 * 60 * 1000),
          },
          status: {
            in: ['PENDING', 'CONFIRMED'],
          },
        },
      });

      // Filtrar slots que já estão agendados
      const availableSlots = calendlySlots.filter(slot => {
        const slotStart = new Date(slot.start_time);
        const slotEnd = new Date(slot.end_time);
        
        return !existingAppointments.some(appointment => {
          const appointmentStart = new Date(appointment.startTime);
          const appointmentEnd = new Date(appointment.endTime);
          
          return (
            (slotStart >= appointmentStart && slotStart < appointmentEnd) ||
            (slotEnd > appointmentStart && slotEnd <= appointmentEnd) ||
            (slotStart <= appointmentStart && slotEnd >= appointmentEnd)
          );
        });
      });

      // Transformar para o formato esperado
      return availableSlots.map((slot, index) => ({
        id: `slot-${index}`,
        date: new Date(slot.start_time).toISOString().split('T')[0],
        startTime: new Date(slot.start_time).toISOString().split('T')[1].substring(0, 5),
        endTime: new Date(slot.end_time).toISOString().split('T')[1].substring(0, 5),
        isAvailable: true,
      }));
    } catch (error) {
      console.error('Erro ao obter slots disponíveis:', error);
      throw error;
    }
  }

  async getAppointmentsByPatient(email: string) {
    try {
      return await db.appointment.findMany({
        where: {
          patientEmail: email,
        },
        orderBy: {
          appointmentDate: 'desc',
        },
      });
    } catch (error) {
      console.error('Erro ao buscar agendamentos do paciente:', error);
      throw error;
    }
  }

  async updateAppointmentStatus(id: string, status: 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'COMPLETED') {
    try {
      return await db.appointment.update({
        where: { id },
        data: { status },
      });
    } catch (error) {
      console.error('Erro ao atualizar status do agendamento:', error);
      throw error;
    }
  }

  async cancelAppointment(id: string) {
    try {
      const appointment = await db.appointment.findUnique({
        where: { id },
      });

      if (!appointment) {
        throw new Error('Agendamento não encontrado');
      }

      // Atualizar status para cancelado
      await db.appointment.update({
        where: { id },
        data: { status: 'CANCELLED' },
      });

      // Liberar o slot
      await this.updateSlotAvailability(appointment.startTime, appointment.endTime, true);

      return { message: 'Agendamento cancelado com sucesso' };
    } catch (error) {
      console.error('Erro ao cancelar agendamento:', error);
      throw error;
    }
  }

  async syncWithCalendly() {
    try {
      // Sincronizar disponibilidade do Calendly com o banco de dados
      const calendlySlots = await this.calendlyService.getAvailableAppointments(30);
      
      for (const slot of calendlySlots) {
        const startTime = new Date(slot.start_time);
        const endTime = new Date(slot.end_time);
        
        await db.availability.upsert({
          where: {
            date_startTime_endTime: {
              date: new Date(startTime.toDateString()),
              startTime: startTime,
              endTime: endTime,
            },
          },
          update: {
            isAvailable: true,
          },
          create: {
            date: new Date(startTime.toDateString()),
            startTime: startTime,
            endTime: endTime,
            isAvailable: true,
          },
        });
      }

      return { message: 'Sincronização concluída com sucesso' };
    } catch (error) {
      console.error('Erro ao sincronizar com Calendly:', error);
      throw error;
    }
  }

  async getDailyAppointments(date: Date) {
    try {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);

      return await db.appointment.findMany({
        where: {
          appointmentDate: {
            gte: startOfDay,
            lte: endOfDay,
          },
          status: {
            in: ['PENDING', 'CONFIRMED'],
          },
        },
        orderBy: {
          startTime: 'asc',
        },
      });
    } catch (error) {
      console.error('Erro ao buscar agendamentos diários:', error);
      throw error;
    }
  }
}