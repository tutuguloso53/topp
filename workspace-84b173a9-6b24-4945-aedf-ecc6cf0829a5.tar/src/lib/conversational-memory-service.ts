import { createMemoryService, IMemoryService, MemoryEntry, UserProfile, ConversationSession } from './memory-service-factory';

export interface ConversationContext {
  sessionId: string;
  userId?: string;
  history: MemoryEntry[];
  userProfile?: UserProfile;
  relevantMemories: MemoryEntry[];
  sessionSummary?: string;
}

export class ConversationalMemoryService {
  private activeSessions: Map<string, ConversationContext> = new Map();
  private memoryService: IMemoryService;

  constructor() {
    this.memoryService = createMemoryService();
  }

  async initializeSession(sessionId: string, userId?: string): Promise<ConversationContext> {
    try {
      // Criar ou recuperar sessão
      await this.memoryService.createSession(sessionId, userId);

      // Buscar histórico de conversas
      const history = await this.memoryService.getConversationHistory(sessionId, 20);

      // Buscar perfil do usuário
      let userProfile: UserProfile | undefined;
      if (userId) {
        userProfile = await this.memoryService.getUserProfile(userId);
      }

      // Buscar memórias relevantes
      let relevantMemories: MemoryEntry[] = [];
      if (userId) {
        relevantMemories = await this.getRelevantContext(userId, history);
      }

      const context: ConversationContext = {
        sessionId,
        userId,
        history: history.reverse(), // Ordem cronológica
        userProfile,
        relevantMemories,
      };

      this.activeSessions.set(sessionId, context);
      return context;
    } catch (error) {
      console.error('Erro ao inicializar sessão:', error);
      // Criar contexto básico mesmo com erro
      const basicContext: ConversationContext = {
        sessionId,
        userId,
        history: [],
        userProfile: undefined,
        relevantMemories: [],
      };
      
      // Adicionar à sessão ativa
      this.activeSessions.set(sessionId, basicContext);
      return basicContext;
    }
  }

  async saveConversation(
    sessionId: string, 
    userMessage: string, 
    aiResponse: string,
    contextTags?: string[]
  ): Promise<void> {
    try {
      const context = this.activeSessions.get(sessionId);
      if (!context) {
        throw new Error('Sessão não encontrada');
      }

      // Salvar no serviço de memória
      await this.memoryService.saveMemory({
        session_id: sessionId,
        user_id: context.userId,
        message: userMessage,
        response: aiResponse,
        context_tags: contextTags,
        importance_score: this.calculateImportanceScore(userMessage, aiResponse),
      });

      // Atualizar contexto local
      context.history.push({
        session_id: sessionId,
        user_id: context.userId,
        message: userMessage,
        response: aiResponse,
        timestamp: new Date(),
        context_tags: contextTags || [],
      });

      // Manter apenas as últimas 50 conversas no contexto
      if (context.history.length > 50) {
        context.history = context.history.slice(-50);
      }

      // Extrair e atualizar informações do perfil
      if (context.userId) {
        await this.extractAndUpdateProfile(sessionId, context.userId, userMessage);
      }

    } catch (error) {
      console.error('Erro ao salvar conversa:', error);
      throw error;
    }
  }

  async getConversationContext(sessionId: string): Promise<ConversationContext> {
    const context = this.activeSessions.get(sessionId);
    if (!context) {
      throw new Error('Sessão não encontrada');
    }
    return context;
  }

  async endSession(sessionId: string): Promise<void> {
    try {
      const context = this.activeSessions.get(sessionId);
      if (!context) {
        throw new Error('Sessão não encontrada');
      }

      // Gerar resumo da sessão
      const summary = await this.memoryService.generateConversationSummary(sessionId);

      // Atualizar sessão
      await this.memoryService.updateSession(sessionId, {
        status: 'ended',
        end_time: new Date(),
        summary,
      });

      // Remover da memória ativa
      this.activeSessions.delete(sessionId);
    } catch (error) {
      console.error('Erro ao encerrar sessão:', error);
      throw error;
    }
  }

  async searchRelevantInformation(userId: string, query: string): Promise<MemoryEntry[]> {
    try {
      return await this.memoryService.searchRelevantMemories(userId, query, 10);
    } catch (error) {
      console.error('Erro ao buscar informações relevantes:', error);
      return [];
    }
  }

  async updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile> {
    try {
      return await this.memoryService.updateUserProfile(userId, updates);
    } catch (error) {
      console.error('Erro ao atualizar perfil do usuário:', error);
      throw error;
    }
  }

  private async getRelevantContext(userId: string, recentHistory: MemoryEntry[]): Promise<MemoryEntry[]> {
    try {
      // Extrair tópicos importantes das conversas recentes
      const recentTopics = this.extractTopics(recentHistory);
      
      // Buscar memórias relevantes baseadas nos tópicos
      const relevantMemories: MemoryEntry[] = [];
      
      for (const topic of recentTopics) {
        const memories = await this.memoryService.searchRelevantMemories(userId, topic, 5);
        relevantMemories.push(...memories);
      }

      // Remover duplicatas e limitar resultados
      const uniqueMemories = this.removeDuplicates(relevantMemories);
      return uniqueMemories.slice(0, 10);
    } catch (error) {
      console.error('Erro ao obter contexto relevante:', error);
      return [];
    }
  }

  private extractTopics(history: MemoryEntry[]): string[] {
    const topics: string[] = [];
    
    // Palavras-chave para extração de tópicos
    const keywords = {
      dental: ['dente', 'dor', 'tratamento', 'procedimento', 'clínico', 'saúde bucal', 'implante', 'prótese'],
      scheduling: ['agendar', 'marcar', 'horário', 'consulta', 'disponibilidade', 'agenda'],
      plans: ['plano', 'assinatura', 'valor', 'preço', 'cobertura', 'mensalidade'],
      emergency: ['urgente', 'emergência', 'dor', 'sos', 'ajuda imediata'],
      general: ['clínica', 'serviços', 'sobre', 'contato', 'endereço']
    };

    for (const entry of history) {
      const text = (entry.message + ' ' + entry.response).toLowerCase();
      
      for (const [category, categoryKeywords] of Object.entries(keywords)) {
        if (categoryKeywords.some(keyword => text.includes(keyword))) {
          topics.push(category);
        }
      }
    }

    return [...new Set(topics)]; // Remover duplicatas
  }

  private removeDuplicates(memories: MemoryEntry[]): MemoryEntry[] {
    const seen = new Set();
    return memories.filter(memory => {
      const key = `${memory.message}-${memory.response}`;
      if (seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  }

  private calculateImportanceScore(userMessage: string, aiResponse: string): number {
    let score = 1; // Score base

    // Aumentar score para mensagens com informações importantes
    const importantKeywords = [
      'nome', 'email', 'telefone', 'contato',
      'agendar', 'marcar consulta', 'disponibilidade',
      'tratamento', 'procedimento', 'dor',
      'plano', 'assinatura', 'valor',
      'urgente', 'emergência'
    ];

    const text = (userMessage + ' ' + aiResponse).toLowerCase();
    
    for (const keyword of importantKeywords) {
      if (text.includes(keyword)) {
        score += 0.5;
      }
    }

    // Aumentar score para mensagens longas (provavelmente mais detalhadas)
    if (userMessage.length > 100) score += 0.3;
    if (aiResponse.length > 200) score += 0.2;

    return Math.min(score, 5); // Limitar score máximo a 5
  }

  private async extractAndUpdateProfile(sessionId: string, userId: string, message: string): Promise<void> {
    try {
      // Extrair informações da mensagem atual
      const extractedInfo = this.extractProfileInfo(message);
      
      if (Object.keys(extractedInfo).length > 0) {
        await this.memoryService.updateUserProfile(userId, extractedInfo);
      }
    } catch (error) {
      console.error('Erro ao extrair e atualizar perfil:', error);
    }
  }

  private extractProfileInfo(message: string): Partial<UserProfile> {
    const info: Partial<UserProfile> = {};

    // Extrair nome
    const nameMatch = message.match(/(?:meu nome é|chamo-me|eu sou)\s+([\w\s]+)/i);
    if (nameMatch) {
      info.name = nameMatch[1].trim();
    }

    // Extrair email
    const emailMatch = message.match(/([\w.-]+@[\w.-]+\.\w+)/);
    if (emailMatch) {
      info.email = emailMatch[1];
    }

    // Extrair telefone
    const phoneMatch = message.match(/(\d{11})|(\d{2}\s?\d{4}\s?\d{4})/);
    if (phoneMatch) {
      info.phone = phoneMatch[1] || phoneMatch[2].replace(/\s/g, '');
    }

    // Extrair informações médicas
    if (message.toLowerCase().includes('alergia')) {
      info.medical_history = {
        ...(info.medical_history || {}),
        allergies: ['Paciente mencionou alergias']
      };
    }

    if (message.toLowerCase().includes('medicamento')) {
      info.medical_history = {
        ...(info.medical_history || {}),
        medications: ['Paciente mencionou medicamentos']
      };
    }

    return info;
  }

  // Gerar prompt de contexto para a IA
  generateContextPrompt(context: ConversationContext): string {
    let prompt = 'CONTEXTO DA CONVERSA:\n\n';

    // Adicionar informações do perfil do usuário
    if (context.userProfile) {
      prompt += 'PERFIL DO USUÁRIO:\n';
      if (context.userProfile.name) {
        prompt += `- Nome: ${context.userProfile.name}\n`;
      }
      if (context.userProfile.email) {
        prompt += `- Email: ${context.userProfile.email}\n`;
      }
      if (context.userProfile.phone) {
        prompt += `- Telefone: ${context.userProfile.phone}\n`;
      }
      if (context.userProfile.medical_history) {
        prompt += '- Histórico Médico: Informações disponíveis\n';
      }
      prompt += '\n';
    }

    // Adicionar memórias relevantes
    if (context.relevantMemories.length > 0) {
      prompt += 'CONVERSAS ANTERIORES RELEVANTES:\n';
      context.relevantMemories.slice(0, 3).forEach((memory, index) => {
        prompt += `${index + 1}. Usuário: ${memory.message}\n`;
        prompt += `   IA: ${memory.response}\n\n`;
      });
    }

    // Adicionar histórico recente
    if (context.history.length > 0) {
      prompt += 'HISTÓRICO RECENTE DA SESSÃO:\n';
      context.history.slice(-5).forEach((entry, index) => {
        prompt += `${index + 1}. Usuário: ${entry.message}\n`;
        prompt += `   IA: ${entry.response}\n\n`;
      });
    }

    return prompt + '\n--- FIM DO CONTEXTO ---\n\n';
  }
}

export const conversationalMemoryService = new ConversationalMemoryService();