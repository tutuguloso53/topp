import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://iakkzsfghhyunphhdwke.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlha2t6c2ZnaGh5dW5waGhkd2tlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUyMjA2MzQsImV4cCI6MjA3MDc5NjYzNH0.kLvH32DdBYiimPhYTesTGeZBba9q5CtfGUCl4hmc608';

// Configuração do cliente Supabase com opções de conexão direta
export const supabase = createClient(supabaseUrl, supabaseKey, {
  db: {
    schema: 'public',
  },
  auth: {
    persistSession: false,
  },
});

// Interface para a memória da IA
export interface MemoryEntry {
  id?: string;
  session_id: string;
  user_id?: string;
  message: string;
  response: string;
  timestamp: Date;
  context_tags?: string[];
  importance_score?: number;
}

// Interface para o perfil do usuário
export interface UserProfile {
  id?: string;
  user_id: string;
  name?: string;
  email?: string;
  phone?: string;
  preferences?: Record<string, any>;
  medical_history?: {
    dental_procedures?: string[];
    allergies?: string[];
    medications?: string[];
    last_visit?: Date;
  };
  conversation_summary?: string;
  created_at?: Date;
  updated_at?: Date;
}

// Interface para sessão de conversação
export interface ConversationSession {
  id?: string;
  session_id: string;
  user_id?: string;
  start_time: Date;
  end_time?: Date;
  status: 'active' | 'ended' | 'paused';
  topic?: string;
  summary?: string;
  key_points?: string[];
}

class SupabaseMemoryService {
  private supabase = supabase;

  constructor() {
    this.initializeDatabase();
  }

  private async initializeDatabase() {
    try {
      // Verificar se a tabela conversations existe
      const { error: conversationsError } = await this.supabase
        .from('conversations')
        .select('id')
        .limit(1);

      if (conversationsError) {
        console.log('Tabela conversations não encontrada, criando...');
        await this.createTables();
      }
    } catch (error) {
      console.log('Inicializando banco de dados...');
      await this.createTables();
    }
  }

  private async createTables() {
    try {
      // Criar tabela conversations
      const { error: conversationsError } = await this.supabase.rpc('create_conversations_table');
      if (conversationsError) {
        console.log('Usando SQL direto para criar tabelas...');
        await this.createTablesWithSQL();
      }
    } catch (error) {
      console.log('Criando tabelas com SQL...');
      await this.createTablesWithSQL();
    }
  }

  private async createTablesWithSQL() {
    try {
      // SQL para criar as tabelas necessárias
      const createTablesSQL = `
        -- Criar tabela conversations se não existir
        CREATE TABLE IF NOT EXISTS conversations (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          session_id TEXT NOT NULL,
          user_id TEXT,
          message TEXT NOT NULL,
          response TEXT NOT NULL,
          timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          context_tags TEXT[] DEFAULT '{}',
          importance_score DECIMAL(3,1) DEFAULT 1.0,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Criar tabela user_profiles se não existir
        CREATE TABLE IF NOT EXISTS user_profiles (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          user_id TEXT UNIQUE NOT NULL,
          name TEXT,
          email TEXT,
          phone TEXT,
          preferences JSONB DEFAULT '{}',
          medical_history JSONB DEFAULT '{}',
          conversation_summary TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Criar tabela conversation_sessions se não existir
        CREATE TABLE IF NOT EXISTS conversation_sessions (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          session_id TEXT UNIQUE NOT NULL,
          user_id TEXT,
          start_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          end_time TIMESTAMP WITH TIME ZONE,
          status TEXT DEFAULT 'active' CHECK (status IN ('active', 'ended', 'paused')),
          topic TEXT,
          summary TEXT,
          key_points TEXT[] DEFAULT '{}',
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Criar índices para melhor performance
        CREATE INDEX IF NOT EXISTS idx_conversations_session_id ON conversations(session_id);
        CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
        CREATE INDEX IF NOT EXISTS idx_conversations_timestamp ON conversations(timestamp);
        CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
        CREATE INDEX IF NOT EXISTS idx_conversation_sessions_session_id ON conversation_sessions(session_id);
        CREATE INDEX IF NOT EXISTS idx_conversation_sessions_user_id ON conversation_sessions(user_id);

        -- Criar função para atualizar updated_at
        CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$ language 'plpgsql';

        -- Criar trigger para atualizar updated_at
        DROP TRIGGER IF EXISTS update_user_profiles_updated_at ON user_profiles;
        CREATE TRIGGER update_user_profiles_updated_at
            BEFORE UPDATE ON user_profiles
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column();
      `;

      // Executar o SQL usando RPC
      const { error } = await this.supabase.rpc('exec_sql', { sql: createTablesSQL });
      
      if (error) {
        console.log('Erro ao executar SQL, tentando método alternativo...');
        // Se o RPC não funcionar, tentamos criar as tabelas uma por uma
        await this.createTablesIndividually();
      } else {
        console.log('Tabelas criadas com sucesso!');
      }
    } catch (error) {
      console.log('Criando tabelas individualmente...');
      await this.createTablesIndividually();
    }
  }

  private async createTablesIndividually() {
    try {
      // Tentar criar cada tabela individualmente usando inserções para forçar criação
      await this.supabase.from('conversations').insert({
        session_id: 'setup',
        message: 'setup',
        response: 'setup',
        timestamp: new Date().toISOString()
      }).then(() => {
        console.log('Tabela conversations OK');
      }).catch(async () => {
        console.log('Tabela conversations precisa ser criada manualmente');
      });

      await this.supabase.from('user_profiles').insert({
        user_id: 'setup',
        name: 'Setup User'
      }).then(() => {
        console.log('Tabela user_profiles OK');
      }).catch(async () => {
        console.log('Tabela user_profiles precisa ser criada manualmente');
      });

      await this.supabase.from('conversation_sessions').insert({
        session_id: 'setup',
        status: 'active',
        start_time: new Date().toISOString()
      }).then(() => {
        console.log('Tabela conversation_sessions OK');
      }).catch(async () => {
        console.log('Tabela conversation_sessions precisa ser criada manualmente');
      });

      // Limpar dados de setup
      await this.supabase.from('conversations').delete().eq('session_id', 'setup');
      await this.supabase.from('user_profiles').delete().eq('user_id', 'setup');
      await this.supabase.from('conversation_sessions').delete().eq('session_id', 'setup');
      
    } catch (error) {
      console.log('Erro ao criar tabelas individualmente:', error);
    }
  }

  async saveMemory(entry: Omit<MemoryEntry, 'id' | 'timestamp'>): Promise<MemoryEntry> {
    try {
      const { data, error } = await this.supabase
        .from('conversations')
        .insert([{
          session_id: entry.session_id,
          user_id: entry.user_id,
          message: entry.message,
          response: entry.response,
          context_tags: entry.context_tags || [],
          importance_score: entry.importance_score || 1.0,
          timestamp: new Date().toISOString(),
        }])
        .select()
        .single();

      if (error) {
        console.error('Erro detalhado ao salvar memória:', error);
        throw error;
      }
      
      return {
        ...data,
        timestamp: new Date(data.timestamp),
      };
    } catch (error) {
      console.error('Erro ao salvar memória:', error);
      throw error;
    }
  }

  async getConversationHistory(sessionId: string, limit: number = 50): Promise<MemoryEntry[]> {
    try {
      const { data, error } = await this.supabase
        .from('conversations')
        .select('*')
        .eq('session_id', sessionId)
        .order('timestamp', { ascending: false })
        .limit(limit);

      if (error) throw error;

      return data.map(entry => ({
        ...entry,
        timestamp: new Date(entry.timestamp),
      }));
    } catch (error) {
      console.error('Erro ao buscar histórico:', error);
      throw error;
    }
  }

  async getUserProfile(userId: string): Promise<UserProfile | null> {
    try {
      const { data, error } = await this.supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') throw error; // PGRST116 = not found
      
      if (data) {
        return {
          ...data,
          medical_history: data.medical_history || {},
          created_at: data.created_at ? new Date(data.created_at) : undefined,
          updated_at: data.updated_at ? new Date(data.updated_at) : undefined,
        };
      }

      return null;
    } catch (error) {
      console.error('Erro ao buscar perfil do usuário:', error);
      throw error;
    }
  }

  async updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile> {
    try {
      const { data, error } = await this.supabase
        .from('user_profiles')
        .upsert([{
          user_id: userId,
          ...updates,
          updated_at: new Date().toISOString(),
        }])
        .select()
        .single();

      if (error) throw error;

      return {
        ...data,
        medical_history: data.medical_history || {},
        created_at: data.created_at ? new Date(data.created_at) : undefined,
        updated_at: data.updated_at ? new Date(data.updated_at) : undefined,
      };
    } catch (error) {
      console.error('Erro ao atualizar perfil do usuário:', error);
      throw error;
    }
  }

  async createSession(sessionId: string, userId?: string, topic?: string): Promise<ConversationSession> {
    try {
      const { data, error } = await this.supabase
        .from('conversation_sessions')
        .insert([{
          session_id: sessionId,
          user_id: userId,
          start_time: new Date().toISOString(),
          status: 'active',
          topic,
        }])
        .select()
        .single();

      if (error) throw error;

      return {
        ...data,
        start_time: new Date(data.start_time),
        end_time: data.end_time ? new Date(data.end_time) : undefined,
      };
    } catch (error) {
      console.error('Erro ao criar sessão:', error);
      throw error;
    }
  }

  async updateSession(sessionId: string, updates: Partial<ConversationSession>): Promise<ConversationSession> {
    try {
      const { data, error } = await this.supabase
        .from('conversation_sessions')
        .update(updates)
        .eq('session_id', sessionId)
        .select()
        .single();

      if (error) throw error;

      return {
        ...data,
        start_time: new Date(data.start_time),
        end_time: data.end_time ? new Date(data.end_time) : undefined,
      };
    } catch (error) {
      console.error('Erro ao atualizar sessão:', error);
      throw error;
    }
  }

  async searchRelevantMemories(userId: string, query: string, limit: number = 10): Promise<MemoryEntry[]> {
    try {
      // Buscar conversas anteriores que possam ser relevantes
      const { data, error } = await this.supabase
        .from('conversations')
        .select('*')
        .eq('user_id', userId)
        .or(`message.ilike.%${query}%,response.ilike.%${query}%`)
        .order('timestamp', { ascending: false })
        .limit(limit);

      if (error) throw error;

      return data.map(entry => ({
        ...entry,
        timestamp: new Date(entry.timestamp),
      }));
    } catch (error) {
      console.error('Erro ao buscar memórias relevantes:', error);
      throw error;
    }
  }

  async generateConversationSummary(sessionId: string): Promise<string> {
    try {
      const history = await this.getConversationHistory(sessionId, 100);
      
      if (history.length === 0) return '';

      // Agrupar mensagens por pares (usuário + IA)
      const conversationPairs = [];
      for (let i = 0; i < history.length; i += 2) {
        if (i + 1 < history.length) {
          conversationPairs.push({
            user: history[i + 1].message,
            ai: history[i].response,
          });
        }
      }

      // Criar um resumo simples
      const summaryPoints = [];
      
      // Extrair informações médicas/dentais
      const dentalKeywords = ['dente', 'dor', 'tratamento', 'consulta', 'procedimento', 'clínico', 'saúde'];
      const medicalInfo = conversationPairs.filter(pair => 
        dentalKeywords.some(keyword => 
          pair.user.toLowerCase().includes(keyword) || 
          pair.ai.toLowerCase().includes(keyword)
        )
      );

      if (medicalInfo.length > 0) {
        summaryPoints.push('Paciente discutiu questões relacionadas a tratamento dentário');
      }

      // Extrair informações de agendamento
      const schedulingKeywords = ['agendar', 'marcar', 'horário', 'consulta', 'disponibilidade'];
      const schedulingInfo = conversationPairs.filter(pair => 
        schedulingKeywords.some(keyword => 
          pair.user.toLowerCase().includes(keyword) || 
          pair.ai.toLowerCase().includes(keyword)
        )
      );

      if (schedulingInfo.length > 0) {
        summaryPoints.push('Paciente demonstrou interesse em agendar consultas');
      }

      // Extrair informações sobre planos
      const planKeywords = ['plano', 'assinatura', 'valor', 'preço', 'cobertura'];
      const planInfo = conversationPairs.filter(pair => 
        planKeywords.some(keyword => 
          pair.user.toLowerCase().includes(keyword) || 
          pair.ai.toLowerCase().includes(keyword)
        )
      );

      if (planInfo.length > 0) {
        summaryPoints.push('Paciente perguntou sobre planos de assinatura');
      }

      return summaryPoints.length > 0 
        ? summaryPoints.join('. ') + '.'
        : 'Conversa geral sobre serviços da clínica';
    } catch (error) {
      console.error('Erro ao gerar resumo da conversa:', error);
      throw error;
    }
  }

  async extractAndUpdateUserProfile(sessionId: string, userId: string): Promise<void> {
    try {
      const history = await this.getConversationHistory(sessionId, 50);
      
      // Extrair informações do histórico
      let name = '';
      let email = '';
      let phone = '';
      const dentalProcedures: string[] = [];
      const preferences: Record<string, any> = {};

      for (const entry of history) {
        // Extrair nome
        const nameMatch = entry.message.match(/meu nome é ([\w\s]+)/i);
        if (nameMatch && !name) {
          name = nameMatch[1].trim();
        }

        // Extrair email
        const emailMatch = entry.message.match(/([\w.-]+@[\w.-]+\.\w+)/);
        if (emailMatch && !email) {
          email = emailMatch[1];
        }

        // Extrair telefone
        const phoneMatch = entry.message.match(/(\d{11})|(\d{2}\s?\d{4}\s?\d{4})/);
        if (phoneMatch && !phone) {
          phone = phoneMatch[1] || phoneMatch[2].replace(/\s/g, '');
        }

        // Extrair procedimentos dentais
        if (entry.message.toLowerCase().includes('tratamento') || 
            entry.message.toLowerCase().includes('procedimento')) {
          dentalProcedures.push(entry.message);
        }

        // Extrair preferências
        if (entry.message.toLowerCase().includes('preferência') || 
            entry.message.toLowerCase().includes('gostaria')) {
          preferences.communication_style = 'detailed';
        }
      }

      // Atualizar perfil do usuário
      const updates: Partial<UserProfile> = {};
      if (name) updates.name = name;
      if (email) updates.email = email;
      if (phone) updates.phone = phone;
      if (dentalProcedures.length > 0) {
        updates.medical_history = { dental_procedures: dentalProcedures };
      }
      if (Object.keys(preferences).length > 0) {
        updates.preferences = preferences;
      }

      if (Object.keys(updates).length > 0) {
        await this.updateUserProfile(userId, updates);
      }
    } catch (error) {
      console.error('Erro ao extrair e atualizar perfil do usuário:', error);
      throw error;
    }
  }
}

export const supabaseMemoryService = new SupabaseMemoryService();