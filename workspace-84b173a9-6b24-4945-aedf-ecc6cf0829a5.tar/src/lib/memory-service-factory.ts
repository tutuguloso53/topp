import { createClient } from '@supabase/supabase-js';
import { MemoryEntry, UserProfile, ConversationSession } from './supabase-memory-service';

// Configuração do cliente Supabase
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

// Interface para o serviço de memória
export interface IMemoryService {
  saveMemory(entry: Omit<MemoryEntry, 'id' | 'timestamp'>): Promise<MemoryEntry>;
  getConversationHistory(sessionId: string, limit?: number): Promise<MemoryEntry[]>;
  getUserProfile(userId: string): Promise<UserProfile | null>;
  updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile>;
  createSession(sessionId: string, userId?: string, topic?: string): Promise<ConversationSession>;
  updateSession(sessionId: string, updates: Partial<ConversationSession>): Promise<ConversationSession>;
  searchRelevantMemories(userId: string, query: string, limit?: number): Promise<MemoryEntry[]>;
  generateConversationSummary(sessionId: string): Promise<string>;
}

// Serviço de memória local (fallback)
class LocalMemoryService implements IMemoryService {
  private conversations: Map<string, MemoryEntry[]> = new Map();
  private userProfiles: Map<string, UserProfile> = new Map();
  private sessions: Map<string, ConversationSession> = new Map();

  async saveMemory(entry: Omit<MemoryEntry, 'id' | 'timestamp'>): Promise<MemoryEntry> {
    const memoryEntry: MemoryEntry = {
      ...entry,
      id: Date.now().toString(),
      timestamp: new Date(),
      context_tags: entry.context_tags || [],
      importance_score: entry.importance_score || 1.0,
    };

    if (!this.conversations.has(entry.session_id)) {
      this.conversations.set(entry.session_id, []);
    }

    this.conversations.get(entry.session_id)!.push(memoryEntry);
    console.log('Memória salva localmente:', memoryEntry);
    return memoryEntry;
  }

  async getConversationHistory(sessionId: string, limit: number = 50): Promise<MemoryEntry[]> {
    const history = this.conversations.get(sessionId) || [];
    return history.slice(-limit).reverse();
  }

  async getUserProfile(userId: string): Promise<UserProfile | null> {
    return this.userProfiles.get(userId) || null;
  }

  async updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile> {
    const existingProfile = this.userProfiles.get(userId) || {
      user_id: userId,
      name: '',
      email: '',
      phone: '',
      preferences: {},
      medical_history: {},
    };

    const updatedProfile: UserProfile = {
      ...existingProfile,
      ...updates,
      user_id: userId,
    };

    this.userProfiles.set(userId, updatedProfile);
    console.log('Perfil atualizado localmente:', updatedProfile);
    return updatedProfile;
  }

  async createSession(sessionId: string, userId?: string, topic?: string): Promise<ConversationSession> {
    const session: ConversationSession = {
      session_id: sessionId,
      user_id: userId,
      start_time: new Date(),
      status: 'active',
      topic,
    };

    this.sessions.set(sessionId, session);
    console.log('Sessão criada localmente:', session);
    return session;
  }

  async updateSession(sessionId: string, updates: Partial<ConversationSession>): Promise<ConversationSession> {
    const existingSession = this.sessions.get(sessionId);
    if (!existingSession) {
      throw new Error('Sessão não encontrada');
    }

    const updatedSession: ConversationSession = {
      ...existingSession,
      ...updates,
    };

    this.sessions.set(sessionId, updatedSession);
    console.log('Sessão atualizada localmente:', updatedSession);
    return updatedSession;
  }

  async searchRelevantMemories(userId: string, query: string, limit: number = 10): Promise<MemoryEntry[]> {
    const allMemories: MemoryEntry[] = [];
    
    for (const [sessionId, memories] of this.conversations) {
      const userMemories = memories.filter(m => m.user_id === userId);
      allMemories.push(...userMemories);
    }

    const queryLower = query.toLowerCase();
    const relevantMemories = allMemories
      .filter(memory => 
        memory.message.toLowerCase().includes(queryLower) ||
        memory.response.toLowerCase().includes(queryLower)
      )
      .slice(-limit);

    return relevantMemories;
  }

  async generateConversationSummary(sessionId: string): Promise<string> {
    const history = await this.getConversationHistory(sessionId, 100);
    
    if (history.length === 0) return '';

    // Simples resumo baseado em palavras-chave
    const allText = history.map(h => h.message + ' ' + h.response).join(' ').toLowerCase();
    
    const summaryPoints = [];
    
    if (allText.includes('dente') || allText.includes('tratamento')) {
      summaryPoints.push('Paciente discutiu questões relacionadas a tratamento dentário');
    }
    
    if (allText.includes('agendar') || allText.includes('consulta')) {
      summaryPoints.push('Paciente demonstrou interesse em agendar consultas');
    }
    
    if (allText.includes('plano') || allText.includes('assinatura')) {
      summaryPoints.push('Paciente perguntou sobre planos de assinatura');
    }

    return summaryPoints.length > 0 
      ? summaryPoints.join('. ') + '.'
      : 'Conversa geral sobre serviços da clínica';
  }
}

// Serviço de memória Supabase
class SupabaseMemoryService implements IMemoryService {
  private supabase = supabase;

  constructor() {
    if (!this.supabase) {
      throw new Error('Supabase não está configurado');
    }
    // Não inicializar o banco de dados no construtor para evitar falhas
  }

  private async initializeDatabase() {
    try {
      // Tentar verificar se as tabelas existem
      const { error } = await this.supabase.from('conversations').select('id').limit(1);
      
      if (error) {
        console.log('Tabelas do Supabase não encontradas, usando fallback local');
        throw error;
      }
    } catch (error) {
      console.log('Falha ao conectar com Supabase, usando fallback local');
      throw error;
    }
  }

  async saveMemory(entry: Omit<MemoryEntry, 'id' | 'timestamp'>): Promise<MemoryEntry> {
    try {
      // Tentar inicializar o banco de dados se necessário
      await this.initializeDatabase();
      
      const { data, error } = await this.supabase
        .from('conversations')
        .insert([{
          session_id: entry.session_id,
          user_id: entry.user_id,
          message: entry.message,
          response: entry.response,
          context_tags: entry.context_tags || [],
          importance_score: entry.importance_score || 1.0,
          timestamp: new Date().toISOString(),
        }])
        .select()
        .single();

      if (error) throw error;
      
      return {
        ...data,
        timestamp: new Date(data.timestamp),
      };
    } catch (error) {
      console.error('Erro ao salvar memória no Supabase:', error);
      throw error;
    }
  }

  async getConversationHistory(sessionId: string, limit: number = 50): Promise<MemoryEntry[]> {
    try {
      const { data, error } = await this.supabase
        .from('conversations')
        .select('*')
        .eq('session_id', sessionId)
        .order('timestamp', { ascending: false })
        .limit(limit);

      if (error) throw error;

      return data.map(entry => ({
        ...entry,
        timestamp: new Date(entry.timestamp),
      }));
    } catch (error) {
      console.error('Erro ao buscar histórico no Supabase:', error);
      throw error;
    }
  }

  async getUserProfile(userId: string): Promise<UserProfile | null> {
    try {
      const { data, error } = await this.supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      
      if (data) {
        return {
          ...data,
          medical_history: data.medical_history || {},
          created_at: data.created_at ? new Date(data.created_at) : undefined,
          updated_at: data.updated_at ? new Date(data.updated_at) : undefined,
        };
      }

      return null;
    } catch (error) {
      console.error('Erro ao buscar perfil no Supabase:', error);
      throw error;
    }
  }

  async updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile> {
    try {
      const { data, error } = await this.supabase
        .from('user_profiles')
        .upsert([{
          user_id: userId,
          ...updates,
          updated_at: new Date().toISOString(),
        }])
        .select()
        .single();

      if (error) throw error;

      return {
        ...data,
        medical_history: data.medical_history || {},
        created_at: data.created_at ? new Date(data.created_at) : undefined,
        updated_at: data.updated_at ? new Date(data.updated_at) : undefined,
      };
    } catch (error) {
      console.error('Erro ao atualizar perfil no Supabase:', error);
      throw error;
    }
  }

  async createSession(sessionId: string, userId?: string, topic?: string): Promise<ConversationSession> {
    try {
      const { data, error } = await this.supabase
        .from('conversation_sessions')
        .insert([{
          session_id: sessionId,
          user_id: userId,
          start_time: new Date().toISOString(),
          status: 'active',
          topic,
        }])
        .select()
        .single();

      if (error) throw error;

      return {
        ...data,
        start_time: new Date(data.start_time),
        end_time: data.end_time ? new Date(data.end_time) : undefined,
      };
    } catch (error) {
      console.error('Erro ao criar sessão no Supabase:', error);
      throw error;
    }
  }

  async updateSession(sessionId: string, updates: Partial<ConversationSession>): Promise<ConversationSession> {
    try {
      const { data, error } = await this.supabase
        .from('conversation_sessions')
        .update(updates)
        .eq('session_id', sessionId)
        .select()
        .single();

      if (error) throw error;

      return {
        ...data,
        start_time: new Date(data.start_time),
        end_time: data.end_time ? new Date(data.end_time) : undefined,
      };
    } catch (error) {
      console.error('Erro ao atualizar sessão no Supabase:', error);
      throw error;
    }
  }

  async searchRelevantMemories(userId: string, query: string, limit: number = 10): Promise<MemoryEntry[]> {
    try {
      const { data, error } = await this.supabase
        .from('conversations')
        .select('*')
        .eq('user_id', userId)
        .or(`message.ilike.%${query}%,response.ilike.%${query}%`)
        .order('timestamp', { ascending: false })
        .limit(limit);

      if (error) throw error;

      return data.map(entry => ({
        ...entry,
        timestamp: new Date(entry.timestamp),
      }));
    } catch (error) {
      console.error('Erro ao buscar memórias relevantes no Supabase:', error);
      throw error;
    }
  }

  async generateConversationSummary(sessionId: string): Promise<string> {
    try {
      const history = await this.getConversationHistory(sessionId, 100);
      
      if (history.length === 0) return '';

      // Simples resumo baseado em palavras-chave
      const allText = history.map(h => h.message + ' ' + h.response).join(' ').toLowerCase();
      
      const summaryPoints = [];
      
      if (allText.includes('dente') || allText.includes('tratamento')) {
        summaryPoints.push('Paciente discutiu questões relacionadas a tratamento dentário');
      }
      
      if (allText.includes('agendar') || allText.includes('consulta')) {
        summaryPoints.push('Paciente demonstrou interesse em agendar consultas');
      }
      
      if (allText.includes('plano') || allText.includes('assinatura')) {
        summaryPoints.push('Paciente perguntou sobre planos de assinatura');
      }

      return summaryPoints.length > 0 
        ? summaryPoints.join('. ') + '.'
        : 'Conversa geral sobre serviços da clínica';
    } catch (error) {
      console.error('Erro ao gerar resumo no Supabase:', error);
      throw error;
    }
  }
}

// Fábrica de serviços de memória
export function createMemoryService(): IMemoryService {
  // Forçar uso do serviço local por enquanto
  console.log('Usando serviço de memória local (forçado)');
  return new LocalMemoryService();
}

// Exportar instância padrão
export const memoryService = createMemoryService();