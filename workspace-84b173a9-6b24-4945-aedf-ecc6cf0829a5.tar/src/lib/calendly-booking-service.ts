// Serviço de integração com Calendly para agendamentos

interface CalendlyTimeSlot {
  start: string;
  end: string;
}

interface CalendlyAvailability {
  days: Array<{
    date: string;
    slots: CalendlyTimeSlot[];
  }>;
}

interface CalendlyEvent {
  uri: string;
  name: string;
  duration: number;
  scheduling_url: string;
}

interface AvailableSlot {
  time: string;
  formattedTime: string;
  bookingUrl: string;
}

class CalendlyBookingService {
  private apiKey: string;
  private baseUrl = 'https://api.calendly.com';
  private eventUri = 'https://calendly.com/over-implants/30min';
  private useRealApi = true; // Usar API real sempre

  constructor() {
    this.apiKey = process.env.CALENDLY_API_KEY || 'eyJraWQiOiIxY2UxZTEzNjE3ZGNmNzY2YjNjZWJjYjY4ZGM1YmFmYThhNjVlNjg0MDIzZjdjMzJiZTgzNDliMjM4MDEzNWI0IiwidHlwIjoiUEFUIiwiYWxnIjoiRVMyNTYifQ.eyJpc3MiOiJodHRwczovL2F1dGguY2FsZW5kbHkuY29tIiwiaWF0IjoxNzU1MjE4NzU3LCJqdGkiOiJmMTA3YTNjNS03N2JjLTRkMjctOWE1Yy02N2Q1YzljOGRlNzAiLCJ1c2VyX3V1aWQiOiIyMDYxYTQ0NC00YjIxLTQ1NWYtODhiYS1jNDVmNGU2NjNmNTMifQ.hJNYk-FtV-ciP8MyyC9Q4JM-2XanirjhnhTePoJU8rd_eynNkzZSKvJBNbVAhPtBzA';
    this.eventUri = process.env.CALENDLY_EVENT_URL || 'https://calendly.com/over-implants/30min';
  }

  private async makeRequest(endpoint: string, params: Record<string, string> = {}) {
    const url = new URL(`${this.baseUrl}${endpoint}`);
    Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Erro na requisição Calendly: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  private parseDate(dateString: string): Date {
    // Lidar com diferentes formatos de data
    if (dateString.includes('/')) {
      // Formato brasileiro: DD/MM/YYYY
      const [day, month, year] = dateString.split('/').map(Number);
      return new Date(year, month - 1, day);
    } else if (dateString.includes('-')) {
      // Formato ISO: YYYY-MM-DD
      return new Date(dateString);
    } else {
      // Tentar parse automático
      return new Date(dateString);
    }
  }

  private formatDateForCalendly(date: Date): string {
    return date.toISOString().split('T')[0];
  }

  private isValidBusinessDay(date: Date): boolean {
    const day = date.getDay();
    // 0 = Domingo, 6 = Sábado
    return day >= 1 && day <= 5; // Segunda a Sexta
  }

  private isValidBusinessTime(hour: number): boolean {
    return hour >= 9 && hour <= 17; // 9h às 17h
  }

  private formatTimeForDisplay(timeString: string): string {
    const date = new Date(timeString);
    return date.toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });
  }

  private generateBookingUrl(date: Date, hour: number): string {
    // Formato: https://calendly.com/over-implants/30min/YYYY-MM-DDTHH:00:00
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hourStr = String(hour).padStart(2, '0');
    
    return `https://calendly.com/over-implants/30min/${year}-${month}-${day}T${hourStr}:00:00`;
  }

  async getAvailableSlots(dateString: string): Promise<AvailableSlot[]> {
    try {
      console.log(`[CALENDLY] Buscando horários para a data: ${dateString}`);
      
      // Parse da data informada pelo usuário
      const requestedDate = this.parseDate(dateString);
      console.log(`[CALENDLY] Data parseada:`, requestedDate);
      
      // Verificar se a data é válida
      if (isNaN(requestedDate.getTime())) {
        throw new Error('Data inválida. Por favor, informe uma data no formato DD/MM/YYYY.');
      }

      // Verificar se está dentro dos próximos 30 dias
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const maxDate = new Date(today);
      maxDate.setDate(maxDate.getDate() + 30);

      if (requestedDate < today) {
        throw new Error(`Esta data (${dateString}) já passou. Por favor, escolha uma data a partir de hoje (${today.toLocaleDateString('pt-BR')}).`);
      }
      
      if (requestedDate > maxDate) {
        throw new Error('A data deve estar dentro dos próximos 30 dias a partir de hoje.');
      }

      // Verificar se é dia útil
      if (!this.isValidBusinessDay(requestedDate)) {
        console.log(`[CALENDLY] Dia não útil:`, requestedDate.getDay());
        return []; // Retorna vazio para dias não úteis
      }

      console.log(`[CALENDLY] Data válida, buscando na API...`);
      
      // Buscar disponibilidade no Calendly
      const calendlyDate = this.formatDateForCalendly(requestedDate);
      console.log(`[CALENDLY] Formatada para Calendly:`, calendlyDate);
      
      // Verificar se deve usar API real ou simulação
      if (this.useRealApi) {
        console.log(`[CALENDLY] Usando API real do Calendly`);
        return await this.getAvailableSlotsFromAPI(calendlyDate, requestedDate);
      } else {
        console.log(`[CALENDLY] Usando modo simulação para desenvolvimento`);
        return await this.getAvailableSlotsSimulation(calendlyDate, requestedDate);
      }

    } catch (error) {
      console.error('[CALENDLY] Erro ao buscar horários disponíveis:', error);
      throw error;
    }
  }

  private async getAvailableSlotsFromAPI(calendlyDate: string, requestedDate: Date): Promise<AvailableSlot[]> {
    try {
      // Primeiro, obter o URI do evento
      const eventInfo = await this.makeRequest('/scheduled_events', {
        user: 'https://api.calendly.com/users/me',
        count: '1',
      });

      let eventUri = this.eventUri; // Fallback para o URI conhecido
      
      if (eventInfo.collection && eventInfo.collection.length > 0) {
        eventUri = eventInfo.collection[0].uri;
      }

      // Buscar disponibilidade para o evento
      const availability = await this.makeRequest(`/event_types/${eventUri.split('/').pop()}/available_times`, {
        start_time: `${calendlyDate}T00:00:00.000Z`,
        end_time: `${calendlyDate}T23:59:59.999Z`,
      });

      console.log('[CALENDLY] Resposta da API Calendly:', availability);

      // Filtrar horários de acordo com as regras de negócio
      const availableSlots: AvailableSlot[] = [];

      if (availability.days && availability.days.length > 0) {
        const dayAvailability = availability.days.find(day => day.date === calendlyDate);
        
        if (dayAvailability && dayAvailability.slots) {
          for (const slot of dayAvailability.slots) {
            const slotDate = new Date(slot.start);
            const hour = slotDate.getHours();
            
            // Verificar regras de negócio
            if (this.isValidBusinessTime(hour) && slotDate.getMinutes() === 0) {
              availableSlots.push({
                time: slot.start,
                formattedTime: this.formatTimeForDisplay(slot.start),
                bookingUrl: this.generateBookingUrl(requestedDate, hour),
              });
            }
          }
        }
      }

      // Ordenar por horário
      availableSlots.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());

      console.log(`[CALENDLY] Encontrados ${availableSlots.length} horários disponíveis`);
      return availableSlots;

    } catch (error) {
      console.error('[CALENDLY] Erro na API do Calendly, fallback para simulação:', error);
      return await this.getAvailableSlotsSimulation(calendlyDate, requestedDate);
    }
  }

  private async getAvailableSlotsSimulation(calendlyDate: string, requestedDate: Date): Promise<AvailableSlot[]> {
    // Gerar horários de teste
    const availableSlots: AvailableSlot[] = [];
    const testHours = [9, 10, 11, 14, 15, 16]; // Horários de teste
    
    for (const hour of testHours) {
      const testDate = new Date(requestedDate);
      testDate.setHours(hour, 0, 0, 0);
      
      availableSlots.push({
        time: testDate.toISOString(),
        formattedTime: `${hour.toString().padStart(2, '0')}:00`,
        bookingUrl: this.generateBookingUrl(requestedDate, hour),
      });
    }
    
    console.log(`[CALENDLY] Gerados ${availableSlots.length} horários de teste`);
    return availableSlots;
  }

  formatAvailableSlotsResponse(slots: AvailableSlot[], dateString: string): string {
    if (slots.length === 0) {
      return `Para o dia ${dateString}, não encontrei nenhum horário disponível que siga nossas regras (de segunda a sexta, das 9h às 17h, em horas cheias). Gostaria de tentar outra data?`;
    }

    let response = `Perfeito! Para o dia ${dateString}, encontrei os seguintes horários disponíveis. Clique no horário que preferir para confirmar:\n\n`;

    slots.forEach((slot, index) => {
      response += `[Agendar para as ${slot.formattedTime}](${slot.bookingUrl})\n`;
    });

    response += '\nSe nenhum desses horários funcionar para você, é só me dizer outra data! 😊';

    return response;
  }

  // Método para extrair data da mensagem do usuário
  extractDateFromMessage(message: string): string | null {
    // Padrões comuns de data em português
    const patterns = [
      /(\d{2})\/(\d{2})\/(\d{4})/, // DD/MM/YYYY
      /(\d{2})\/(\d{2})/, // DD/MM (ano atual)
      /(\d{1,2})\s+de\s+(\w+)\s+de\s+(\d{4})/i, // 15 de janeiro de 2024
      /(\d{1,2})\s+de\s+(\w+)/i, // 15 de janeiro (ano atual)
    ];

    for (const pattern of patterns) {
      const match = message.match(pattern);
      if (match) {
        if (pattern.source.includes('\\/')) {
          // Formato com barras
          if (match.length === 4) {
            return match[0]; // DD/MM/YYYY
          } else if (match.length === 3) {
            // DD/MM - adicionar ano atual
            const year = new Date().getFullYear();
            return `${match[0]}/${year}`;
          }
        } else {
          // Formato textual
          const day = match[1];
          const monthText = match[2].toLowerCase();
          const year = match[3] || new Date().getFullYear().toString();
          
          // Converter mês textual para número
          const monthMap: Record<string, string> = {
            'janeiro': '01',
            'fevereiro': '02',
            'março': '03',
            'abril': '04',
            'maio': '05',
            'junho': '06',
            'julho': '07',
            'agosto': '08',
            'setembro': '09',
            'outubro': '10',
            'novembro': '11',
            'dezembro': '12',
          };
          
          const month = monthMap[monthText];
          if (month) {
            return `${day.padStart(2, '0')}/${month}/${year}`;
          }
        }
      }
    }

    return null;
  }

  // Método para validar data
  validateDate(dateString: string): { isValid: boolean; formattedDate?: string; error?: string } {
    try {
      const date = this.parseDate(dateString);
      
      if (isNaN(date.getTime())) {
        return { isValid: false, error: 'Data inválida. Por favor, informe uma data no formato DD/MM/YYYY.' };
      }

      // Verificar se está dentro dos próximos 30 dias
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const maxDate = new Date(today);
      maxDate.setDate(maxDate.getDate() + 30);

      if (date < today) {
        return { isValid: false, error: `Esta data (${dateString}) já passou. Por favor, escolha uma data a partir de hoje (${today.toLocaleDateString('pt-BR')}).` };
      }
      
      if (date > maxDate) {
        return { isValid: false, error: 'A data deve estar dentro dos próximos 30 dias a partir de hoje.' };
      }

      // Verificar se é dia útil
      if (!this.isValidBusinessDay(date)) {
        return { isValid: false, error: 'A data deve ser em um dia útil (segunda a sexta).' };
      }

      return { 
        isValid: true, 
        formattedDate: this.formatDateForCalendly(date) 
      };
    } catch (error) {
      return { isValid: false, error: 'Não foi possível processar a data informada.' };
    }
  }

  // Método para verificar se um horário específico está disponível
  async checkSpecificTimeAvailability(dateString: string, timeString: string): Promise<{ available: boolean; bookingUrl?: string; alternativeSlots?: AvailableSlot[] }> {
    try {
      console.log(`[CALENDLY] Verificando disponibilidade para data: ${dateString}, horário: ${timeString}`);
      
      // Parse da data informada pelo usuário
      const requestedDate = this.parseDate(dateString);
      console.log(`[CALENDLY] Data parseada:`, requestedDate);
      
      // Verificar se a data é válida
      if (isNaN(requestedDate.getTime())) {
        throw new Error('Data inválida. Por favor, informe uma data no formato DD/MM/YYYY.');
      }

      // Verificar se está dentro dos próximos 30 dias
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const maxDate = new Date(today);
      maxDate.setDate(maxDate.getDate() + 30);

      if (requestedDate < today) {
        throw new Error(`Esta data (${dateString}) já passou. Por favor, escolha uma data a partir de hoje (${today.toLocaleDateString('pt-BR')}).`);
      }
      
      if (requestedDate > maxDate) {
        throw new Error('A data deve estar dentro dos próximos 30 dias a partir de hoje.');
      }

      // Verificar se é dia útil
      if (!this.isValidBusinessDay(requestedDate)) {
        return { 
          available: false, 
          alternativeSlots: [] 
        };
      }

      // Parse do horário solicitado
      let requestedHour: number;
      if (timeString.includes(':')) {
        requestedHour = parseInt(timeString.split(':')[0]);
      } else {
        // Tentar converter formato como "10h" ou "10"
        requestedHour = parseInt(timeString.replace('h', ''));
      }

      if (isNaN(requestedHour) || !this.isValidBusinessTime(requestedHour)) {
        throw new Error('Horário inválido. Nosso horário de atendimento é das 9h às 17h, em horas cheias.');
      }

      console.log(`[CALENDLY] Horário solicitado: ${requestedHour}h`);
      
      // Buscar todos os slots disponíveis para o dia
      const allAvailableSlots = await this.getAvailableSlots(dateString);
      
      // Verificar se o horário específico está disponível
      const specificSlot = allAvailableSlots.find(slot => {
        const slotDate = new Date(slot.time);
        return slotDate.getHours() === requestedHour;
      });

      if (specificSlot) {
        console.log(`[CALENDLY] Horário ${requestedHour}h está disponível!`);
        return {
          available: true,
          bookingUrl: specificSlot.bookingUrl
        };
      } else {
        console.log(`[CALENDLY] Horário ${requestedHour}h não está disponível.`);
        return {
          available: false,
          alternativeSlots: allAvailableSlots.slice(0, 3) // Mostrar até 3 alternativas
        };
      }

    } catch (error) {
      console.error('[CALENDLY] Erro ao verificar disponibilidade específica:', error);
      throw error;
    }
  }

  // Método para extrair data E horário da mensagem do usuário
  extractDateTimeFromMessage(message: string): { date: string | null; time: string | null } {
    // Extrair data
    const date = this.extractDateFromMessage(message);
    
    // Padrões para extrair horário
    const timePatterns = [
      /(\d{1,2}):(\d{2})/, // 14:30
      /(\d{1,2})h/, // 14h
      /(\d{1,2})\s*horas/, // 14 horas
      /às\s+(\d{1,2})(?::\d{2})?\s*h?/, // às 14 ou às 14:30
      /(\d{1,2})/ // 14 (contexto de agendamento)
    ];

    let time: string | null = null;
    
    for (const pattern of timePatterns) {
      const match = message.match(pattern);
      if (match) {
        const hour = match[1] || match[2];
        if (hour && parseInt(hour) >= 0 && parseInt(hour) <= 23) {
          time = hour.padStart(2, '0');
          break;
        }
      }
    }

    return { date, time };
  }

  formatSpecificTimeResponse(available: boolean, bookingUrl?: string, alternativeSlots?: AvailableSlot[], dateString?: string, timeString?: string): string {
    if (available && bookingUrl) {
      return `Perfeito! O horário ${timeString}h do dia ${dateString} está disponível. Você pode confirmar seu agendamento clicando no link abaixo:

[Confirmar Agendamento](${bookingUrl})

Fico feliz em ajudar com seu agendamento! 😊`;
    } else {
      let response = `Desculpe, o horário ${timeString}h do dia ${dateString} não está disponível.`;
      
      if (alternativeSlots && alternativeSlots.length > 0) {
        response += '\n\nMas encontrei estes outros horários disponíveis no mesmo dia:\n\n';
        alternativeSlots.forEach(slot => {
          response += `• [Agendar para as ${slot.formattedTime}](${slot.bookingUrl})\n`;
        });
      } else {
        response += '\n\nNão encontrei outros horários disponíveis neste dia.';
      }
      
      response += '\n\nGostaria de tentar outro dia ou horário?';

      return response;
    }
  }

  // Método para verificar se o usuário quer agendar
  isSchedulingRequest(message: string): boolean {
    const schedulingKeywords = [
      'agendar', 'marcar', 'horário', 'consulta', 'disponibilidade',
      'quero agendar', 'gostaria de agendar', 'marcar consulta',
      'agendamento', 'disponíveis', 'agenda'
    ];

    const lowerMessage = message.toLowerCase();
    return schedulingKeywords.some(keyword => lowerMessage.includes(keyword));
  }
}

// Exportar instância única do serviço
export const calendlyBookingService = new CalendlyBookingService();