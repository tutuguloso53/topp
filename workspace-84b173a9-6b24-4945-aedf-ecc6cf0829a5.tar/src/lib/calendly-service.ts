interface CalendlyTimeSlot {
  start_time: string;
  end_time: string;
}

interface CalendlyAvailability {
  availability: CalendlyTimeSlot[];
}

interface Holiday {
  date: string;
  name: string;
  isNational: boolean;
}

export class CalendlyService {
  private apiKey: string;
  private baseUrl = 'https://api.calendly.com';

  constructor() {
    this.apiKey = process.env.CALENDLY_API_KEY || '';
    if (!this.apiKey) {
      throw new Error('CALENDLY_API_KEY não está configurada');
    }
  }

  private async makeRequest(endpoint: string, params: Record<string, string> = {}) {
    const url = new URL(`${this.baseUrl}${endpoint}`);
    Object.entries(params).forEach(([key, value]) => {
      url.searchParams.append(key, value);
    });

    const response = await fetch(url.toString(), {
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Erro na requisição à API do Calendly: ${response.statusText}`);
    }

    return response.json();
  }

  async getAvailability(userUri: string, startDate: string, endDate: string): Promise<CalendlyAvailability> {
    try {
      const response = await this.makeRequest('/user_availability_schedules', {
        user: userUri,
        start_time: startDate,
        end_time: endDate,
      });

      // Transformar a resposta para o formato esperado
      const availability: CalendlyTimeSlot[] = [];
      
      // Aqui você precisará adaptar conforme a resposta real da API do Calendly
      // A estrutura exata depende da sua configuração no Calendly
      if (response.collection && response.collection.length > 0) {
        const schedule = response.collection[0];
        if (schedule.rules && schedule.rules.length > 0) {
          schedule.rules.forEach((rule: any) => {
            if (rule.intervals && rule.intervals.length > 0) {
              rule.intervals.forEach((interval: any) => {
                availability.push({
                  start_time: interval.start_time,
                  end_time: interval.end_time,
                });
              });
            }
          });
        }
      }

      return { availability };
    } catch (error) {
      console.error('Erro ao buscar disponibilidade:', error);
      throw error;
    }
  }

  async getAvailableSlots(eventTypeUri: string, startDate: string, endDate: string): Promise<CalendlyTimeSlot[]> {
    try {
      const response = await this.makeRequest('/scheduled_events', {
        event_type: eventTypeUri,
        start_time: startDate,
        end_time: endDate,
        status: 'active',
      });

      // Obter slots disponíveis (não agendados)
      const allSlots = await this.generateTimeSlots(startDate, endDate);
      const bookedSlots = response.collection.map((event: any) => ({
        start_time: event.start_time,
        end_time: event.end_time,
      }));

      // Filtrar slots já agendados
      const availableSlots = allSlots.filter(slot => 
        !bookedSlots.some(booked => 
          booked.start_time === slot.start_time && booked.end_time === slot.end_time
        )
      );

      return availableSlots;
    } catch (error) {
      console.error('Erro ao buscar slots disponíveis:', error);
      throw error;
    }
  }

  private async generateTimeSlots(startDate: string, endDate: string): Promise<CalendlyTimeSlot[]> {
    const slots: CalendlyTimeSlot[] = [];
    const start = new Date(startDate);
    const end = new Date(endDate);
    const current = new Date(start);

    while (current <= end) {
      // Apenas dias úteis (segunda a sexta)
      const dayOfWeek = current.getDay();
      if (dayOfWeek >= 1 && dayOfWeek <= 5) {
        // Horário de funcionamento: 9h00 às 17h00
        const dayStart = new Date(current);
        dayStart.setHours(9, 0, 0, 0);
        
        const dayEnd = new Date(current);
        dayEnd.setHours(17, 0, 0, 0);

        // Gerar slots de 1 hora
        let slotStart = new Date(dayStart);
        while (slotStart < dayEnd) {
          const slotEnd = new Date(slotStart);
          slotEnd.setHours(slotStart.getHours() + 1);

          slots.push({
            start_time: slotStart.toISOString(),
            end_time: slotEnd.toISOString(),
          });

          slotStart = new Date(slotEnd);
        }
      }

      current.setDate(current.getDate() + 1);
    }

    return slots;
  }

  async isHoliday(date: Date): Promise<boolean> {
    // Verificar feriados nacionais do Brasil
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();

    // Feriados nacionais fixos
    const fixedHolidays = [
      { month: 1, day: 1 },   // Confraternização Universal
      { month: 4, day: 21 },  // Tiradentes
      { month: 5, day: 1 },   // Dia do Trabalho
      { month: 9, day: 7 },   // Independência do Brasil
      { month: 10, day: 12 }, // Nossa Senhora Aparecida
      { month: 11, day: 2 },  // Finados
      { month: 11, day: 15 }, // Proclamação da República
      { month: 12, day: 25 }, // Natal
    ];

    // Verificar feriados fixos
    const isFixedHoliday = fixedHolidays.some(holiday => 
      holiday.month === month && holiday.day === day
    );

    if (isFixedHoliday) return true;

    // Calcular feriados móveis (Páscoa, Corpus Christi, etc.)
    const easter = this.calculateEaster(year);
    const carnival = new Date(easter);
    carnival.setDate(easter.getDate() - 47);
    
    const goodFriday = new Date(easter);
    goodFriday.setDate(easter.getDate() - 2);
    
    const corpusChristi = new Date(easter);
    corpusChristi.setDate(easter.getDate() - 60);

    const movableHolidays = [
      carnival,      // Carnaval
      goodFriday,   // Sexta-feira Santa
      corpusChristi // Corpus Christi
    ];

    return movableHolidays.some(holiday => 
      holiday.getDate() === day && holiday.getMonth() + 1 === month
    );
  }

  private calculateEaster(year: number): Date {
    // Cálculo da Páscoa (Algoritmo de Gauss)
    const a = year % 19;
    const b = Math.floor(year / 100);
    const c = year % 100;
    const d = Math.floor(b / 4);
    const e = b % 4;
    const f = Math.floor((b + 8) / 25);
    const g = Math.floor((b - f + 1) / 3);
    const h = (19 * a + b - d - g + 15) % 30;
    const i = Math.floor(c / 4);
    const k = c % 4;
    const l = (32 + 2 * e + 2 * i - h - k) % 7;
    const m = Math.floor((a + 11 * h + 22 * l) / 451);
    const month = Math.floor((h + l - 7 * m + 114) / 31);
    const day = ((h + l - 7 * m + 114) % 31) + 1;

    return new Date(year, month - 1, day);
  }

  async getAvailableAppointments(daysAhead: number = 30): Promise<CalendlyTimeSlot[]> {
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(startDate.getDate() + daysAhead);

    const allSlots = await this.generateTimeSlots(
      startDate.toISOString(),
      endDate.toISOString()
    );

    // Filtrar feriados e fins de semana
    const availableSlots = await Promise.all(
      allSlots.map(async (slot) => {
        const slotDate = new Date(slot.start_time);
        const isWeekend = slotDate.getDay() === 0 || slotDate.getDay() === 6;
        const isHoliday = await this.isHoliday(slotDate);
        
        return (!isWeekend && !isHoliday) ? slot : null;
      })
    );

    return availableSlots.filter((slot): slot is CalendlyTimeSlot => slot !== null);
  }
}