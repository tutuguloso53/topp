import { HeroSection } from "@/components/site/hero-section";
import { ApresentacaoSection } from "@/components/site/apresentacao-section";
import { ServicosSection } from "@/components/site/servicos-section";
import { SaudeBucalSection } from "@/components/site/saude-bucal-section";
import { SobreSection } from "@/components/site/sobre-section";
import { PlanosSection } from "@/components/site/planos-section";
import { BlogSection } from "@/components/site/blog-section";
import { NovidadesSection } from "@/components/site/novidades-section";
import { DiferenciaisSection } from "@/components/site/diferenciais-section";
import { DepoimentosSection } from "@/components/site/depoimentos-section";
import { ContatoSection } from "@/components/site/contato-section";

export default function Home() {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <ApresentacaoSection />
      <ServicosSection />
      <SaudeBucalSection />
      <SobreSection />
      <PlanosSection />
      <BlogSection />
      <NovidadesSection />
      <DiferenciaisSection />
      <DepoimentosSection />
      <ContatoSection />
    </main>
  );
}