import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Navigation } from "@/components/site/navigation";
import { Footer } from "@/components/site/footer";
import { WhatsAppButton } from "@/components/site/whatsapp-button";
import { Chatbot } from "@/components/site/chatbot";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Over Implantes - Clínica Odontológica em Santo André",
  description: "Clínica odontológica moderna e elegante em Santo André. Especialistas em implantes dentários, ortodontia, endodontia e harmonização facial. Agende sua consulta via WhatsApp.",
  keywords: ["Over Implantes", "clínica odontológica", "implantes dentários", "ortodontia", "endodontia", "Santo André", "dentista", "saúde bucal"],
  authors: [{ name: "Over Implantes" }],
  openGraph: {
    title: "Over Implantes - Clínica Odontológica em Santo André",
    description: "Clínica odontológica moderna e elegante em Santo André. Especialistas em implantes dentários, ortodontia, endodontia e harmonização facial.",
    url: "https://overimplantes.com.br",
    siteName: "Over Implantes",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Over Implantes - Clínica Odontológica em Santo André",
    description: "Clínica odontológica moderna e elegante em Santo André. Especialistas em implantes dentários, ortodontia, endodontia e harmonização facial.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Navigation />
        <main>{children}</main>
        <Footer />
        <WhatsAppButton />
        <Chatbot />
        <Toaster />
      </body>
    </html>
  );
}
