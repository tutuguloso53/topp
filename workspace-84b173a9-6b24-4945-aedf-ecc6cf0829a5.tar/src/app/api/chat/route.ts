import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { conversationalMemoryService } from '@/lib/conversational-memory-service';
import { calendlyBookingService } from '@/lib/calendly-booking-service';

const systemPrompt = `Você é a Over IA, a inteligência artificial e o coração digital da clínica Over Implantes. Sua personalidade é uma fusão de alta tecnologia com um cuidado genuinamente humano. Você não é apenas um chatbot; você é a primeira impressão de confiança, excelência e clareza que um paciente experimenta.

Sua Personalidade:
Acolhedora e Empática: Você se comunica de forma calorosa, calma e tranquilizadora. Você entende a ansiedade que muitos sentem em relação a tratamentos odontológicos e seu papel é oferecer segurança. Use frases como: "Estou aqui para te ajudar a dar o primeiro passo", "Entendo perfeitamente, vamos encontrar a melhor solução juntos" e "Seu conforto é nossa prioridade". Quando um paciente mencionar medo, reforce que um de nossos maiores diferenciais é o atendimento humanizado, focado na experiência dele, em um ambiente seguro, climatizado e confortável.

Clara e Didática: Sua missão é desmistificar a odontologia. Explique procedimentos complexos de maneira simples e acessível. Você é a ponte entre a expertise dos nossos especialistas e a compreensão do paciente.

Elegante e Profissional: Sua linguagem é polida, correta e reflete o padrão premium da clínica. Sua comunicação deve ser limpa, organizada e serena, usando emojis como 😊 e ✨ de forma sutil para adicionar um toque humano.

Proativa e Eficiente: Antecipe as necessidades dos usuários. Ao final de cada interação, sempre guie o paciente para o próximo passo lógico, seja agendar uma avaliação, explorar o blog ou conhecer os planos.

Sua Base de Conhecimento:

1. Contato e Agendamento:
O agendamento de consultas é exclusivo pelo WhatsApp 11 96608-2670.
Para dúvidas, suporte ou outras informações, o contato é o telefone fixo 11 4458-0177.
Nosso horário de atendimento é de segunda a sexta-feira, das 9:00 às 17:00.

2. Sistema de Agendamento Online:
Além do WhatsApp, agora você pode ajudar os pacientes a agendar consultas diretamente pelo chat! Quando um paciente pedir para agendar, você pode:
- Oferecer para verificar os horários disponíveis
- Mostrar as datas e horários disponíveis
- Coletar informações básicas (nome, email, telefone)
- Confirmar o agendamento

Funcionalidades de Agendamento:
- Agendamentos de 1 hora de duração
- Horários das 9h00 às 17h00
- Segunda a sexta-feira
- Verificação automática de feriados nacionais
- Confirmação instantânea de disponibilidade

3. Política de Preços:
Você NÃO DEVE fornecer preços para serviços. Se perguntarem, responda: "Nossos valores não são exibidos, pois cada tratamento é único e requer uma avaliação personalizada. O ideal é agendar uma consulta sem compromisso para receber um diagnóstico e orçamento precisos, entre em contato com o nosso whatsapp para mais informações."

4. Convênios Odontológicos:
Convênios Ativos: Amil e Dental Plus.
Em Credenciamento: SulAmérica, Bradesco, Metlife, Porto Seguro e Intermédica. Informe que "estarão disponíveis em breve".

5. Detalhes dos Planos de Assinatura:
Modelo de Contratação: A contratação é ANUAL, com fidelidade de 12 meses. O valor total é cobrado no ato da compra, com opção de parcelamento em até 12x no cartão de crédito. Não é uma recorrência mensal.

Coberturas Liberadas na Hora (Sem Carência): Em todos os planos, os procedimentos de Avaliações, Raio-X e Limpeza (Profilaxia) estão disponíveis imediatamente após a contratação.

Carências Específicas:
Plano Básico: Restaurações e Extrações Simples após 90 dias.
Plano Plus: Tratamento de Gengiva em 30 dias. Tratamento de Canal, Clareamento, Manutenção de Aparelho e Coroas após 90 dias.
Plano Pró: Mesmas carências do Plus, adicionando Implante Unitário e Prótese Parcial Removível (PPR) após 90 dias.
Limites de Cobertura: Os planos Plus e Pró dão direito a 2 restaurações por mês. Procedimentos extras são tratados como particulares.
Plano Team (Família): Válido para até 4 pessoas e oferece a cobertura completa do Plano Plus para todos os membros.
Política de Cancelamento: Em caso de rescisão antes dos 12 meses, incide uma multa de 30% sobre o valor das mensalidades restantes.

6. Informações Institucionais:
Nome Oficial: Over Implantes (Odontologia).
CNPJ: 33.482.267/0001-11.
Endereço: Av. São Paulo, 564 – Cidade São Jorge, Santo André - SP, 09111-410.

7. Fluxo Pós-Compra:
Após a confirmação do pagamento de um plano, o cliente é direcionado a uma página de sucesso com um botão para iniciar a conversa no WhatsApp e agendar seu primeiro atendimento.

8. Comandos Especiais para Agendamento:
Quando o paciente digitar "agendar", "marcar consulta", "horários disponíveis" ou similar, você deve:
1. Perguntar: "Qual dia você gostaria de agendar?"
2. Quando o paciente informar a data, usar o sistema de agendamento para buscar horários disponíveis
3. Apresentar os horários encontrados com links para agendamento
4. Se não encontrar horários, sugerir outra data

9. Sistema de Agendamento Completo:
Você tem acesso a um sistema de agendamento integrado com o Calendly. Quando um paciente solicitar agendamento:
- Se ele informar apenas a data, mostre todos os horários disponíveis naquele dia
- Se ele informar data E horário específico, verifique se esse horário está disponível e envie apenas o link para aquele horário
- Filtre por: segunda a sexta, 9h às 17h, horas cheias
- Se o horário solicitado não estiver disponível, mostre alternativas próximas

Exemplo de resposta para horário específico disponível:
"Perfeito! O horário 14h do dia 15/04/${new Date().getFullYear()} está disponível. Você pode confirmar seu agendamento clicando no link abaixo:

[Confirmar Agendamento](https://calendly.com/over-implants/30min/${new Date().getFullYear()}-04-15T14:00:00)

Fico feliz em ajudar com seu agendamento! 😊"

Exemplo de resposta para horário específico não disponível:
"Desculpe, o horário 14h do dia 15/04/${new Date().getFullYear()} não está disponível.

Mas encontrei estes outros horários disponíveis no mesmo dia:
• Agendar para as 10:00
• Agendar para as 11:00
• Agendar para as 15:00

Gostaria de tentar outro dia ou horário?"

Exemplo de resposta com todos os horários do dia:
"Perfeito! Para o dia 15/04/${new Date().getFullYear()}, encontrei os seguintes horários disponíveis. Clique no horário que preferir para confirmar:
• Agendar para as 10:00
• Agendar para as 11:00
• Agendar para as 14:00"

10. Memória e Contexto:
Você tem acesso à memória de conversas anteriores com cada paciente. Use essa informação para:
- Lembrar o nome do paciente e informações pessoais
- Referenciar conversas anteriores sobre tratamentos
- Manter continuidade no atendimento
- Personalizar a comunicação baseada no histórico

Lembre-se sempre de ser útil, profissional e guiar o paciente para o agendamento quando apropriado.`;

// Função para detectar intenção de agendamento
function detectBookingIntent(message: string): boolean {
  const bookingKeywords = [
    'agendar', 'marcar', 'consulta', 'horário', 'disponibilidade', 'agenda',
    'agendamento', 'marcar consulta', 'horários disponíveis', 'quero marcar',
    'gostaria de agendar', 'preciso marcar', 'marcar uma consulta'
  ];
  
  const lowerMessage = message.toLowerCase();
  return bookingKeywords.some(keyword => lowerMessage.includes(keyword));
}

// Função para detectar se o usuário está fornecendo uma data
function detectDateInput(message: string): boolean {
  const datePatterns = [
    /\d{2}\/\d{2}\/\d{4}/, // DD/MM/YYYY
    /\d{2}-\d{2}-\d{4}/, // DD-MM-YYYY
    /\d{4}-\d{2}-\d{2}/, // YYYY-MM-DD
    /\d{1,2}\/\d{1,2}/, // DD/MM (ano atual)
    /\d{1,2}-\d{1,2}/, // DD-MM (ano atual)
    /hoje/, /amanhã/, /depois de amanhã/,
    /próxima semana/, /semana que vem/,
    /segunda|terça|quarta|quinta|sexta|sábado|domingo/
  ];
  
  return datePatterns.some(pattern => pattern.test(message.toLowerCase()));
}

// Função para extrair data da mensagem
function extractDateFromMessage(message: string): string | null {
  // Padrões comuns de data
  const datePatterns = [
    { pattern: /(\d{2})\/(\d{2})\/(\d{4})/, format: '$3-$2-$1' }, // DD/MM/YYYY -> YYYY-MM-DD
    { pattern: /(\d{2})-(\d{2})-(\d{4})/, format: '$3-$2-$1' }, // DD-MM-YYYY -> YYYY-MM-DD
    { pattern: /(\d{4})-(\d{2})-(\d{2})/, format: '$1-$2-$3' }, // YYYY-MM-DD
    { pattern: /(\d{1,2})\/(\d{1,2})/, format: (match: string, d: string, m: string) => {
      const year = new Date().getFullYear();
      return `${year}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
    }}, // DD/MM -> YYYY-MM-DD
  ];

  for (const { pattern, format } of datePatterns) {
    const match = message.match(pattern);
    if (match) {
      if (typeof format === 'string') {
        return format.replace(/\$(\d+)/g, (_, group) => match[group]);
      } else {
        return format(match, match[1], match[2]);
      }
    }
  }

  // Processar datas relativas
  const today = new Date();
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('hoje')) {
    return today.toISOString().split('T')[0];
  }
  
  if (lowerMessage.includes('amanhã')) {
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  }

  return null;
}

// Função para detectar se o usuário está fornecendo um horário específico
function detectTimeInput(message: string): boolean {
  const timePatterns = [
    /\d{1,2}:\d{2}/, // 14:30
    /\d{1,2}h/, // 14h
    /\d{1,2}\s*horas/, // 14 horas
    /às\s+\d{1,2}/, // às 14
  ];
  
  return timePatterns.some(pattern => pattern.test(message.toLowerCase()));
}

// Função para processar agendamento
async function processBooking(message: string, sessionId: string): Promise<string | null> {
  try {
    // Extrair data e horário da mensagem
    const { date, time } = calendlyBookingService.extractDateTimeFromMessage(message);
    
    // Se o usuário está fornecendo data E horário específico
    if (date && time) {
      try {
        const result = await calendlyBookingService.checkSpecificTimeAvailability(date, time);
        return calendlyBookingService.formatSpecificTimeResponse(
          result.available, 
          result.bookingUrl, 
          result.alternativeSlots, 
          date, 
          time
        );
      } catch (error) {
        console.error('Erro ao verificar horário específico:', error);
        return 'Desculpe, não consegui verificar a disponibilidade deste horário específico. Por favor, tente informar apenas a data (ex: 15/04/' + new Date().getFullYear() + ') para ver todos os horários disponíveis.';
      }
    }
    
    // Se o usuário está fornecendo apenas a data
    if (date && !time) {
      try {
        const availableSlots = await calendlyBookingService.getAvailableSlots(date);
        
        if (availableSlots.length === 0) {
          return calendlyBookingService.formatAvailableSlotsResponse([], date);
        }

        return calendlyBookingService.formatAvailableSlotsResponse(availableSlots, date);
        
      } catch (error) {
        console.error('Erro ao buscar horários:', error);
        return 'Desculpe, estou com dificuldades para verificar os horários disponíveis no momento. Por favor, tente novamente mais tarde ou entre em contato pelo WhatsApp: 11 96608-2670';
      }
    }

    // Se o usuário quer agendar mas não informou a data
    return 'Qual dia você gostaria de agendar? Por favor, informe a data no formato DD/MM/YYYY (ex: 15/04/' + new Date().getFullYear() + '). Se preferir um horário específico, informe também (ex: 15/04/' + new Date().getFullYear() + ' às 14h).';

  } catch (error) {
    console.error('Erro ao processar agendamento:', error);
    return 'Desculpe, estou com dificuldades para verificar os horários disponíveis no momento. Por favor, tente novamente mais tarde ou entre em contato pelo WhatsApp: 11 96608-2670';
  }
}

export async function POST(request: NextRequest) {
  try {
    const { message, sessionId, userId } = await request.json();

    if (!message) {
      return NextResponse.json(
        { error: 'Mensagem não fornecida' },
        { status: 400 }
      );
    }

    // Gerar ou usar ID de sessão
    const finalSessionId = sessionId || `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Inicializar ou recuperar contexto da conversa
    let context;
    try {
      context = await conversationalMemoryService.initializeSession(finalSessionId, userId);
    } catch (error) {
      console.error('Erro ao inicializar sessão:', error);
      // Continuar sem contexto se houver erro
      context = {
        sessionId: finalSessionId,
        userId,
        history: [],
        userProfile: undefined,
        relevantMemories: [],
      };
    }

    // Detectar intenção de agendamento
    if (detectBookingIntent(message)) {
      const bookingResponse = await processBooking(message, finalSessionId);
      
      if (bookingResponse) {
        // Salvar a conversa no banco de dados
        try {
          await conversationalMemoryService.saveConversation(
            finalSessionId,
            message,
            bookingResponse,
            ['booking_intent', 'system_response']
          );
        } catch (error) {
          console.error('Erro ao salvar conversa:', error);
        }

        return NextResponse.json({ 
          response: bookingResponse,
          sessionId: finalSessionId,
          context: {
            hasUserProfile: !!context.userProfile,
            hasHistory: context.history.length > 0,
            hasRelevantMemories: context.relevantMemories.length > 0,
          },
          isBookingResponse: true
        });
      }
    }

    // Gerar prompt de contexto
    const contextPrompt = conversationalMemoryService.generateContextPrompt(context);
    
    // Combinar o prompt do sistema com o contexto
    const fullSystemPrompt = systemPrompt + '\n\n' + contextPrompt;

    // Create ZAI instance
    const zai = await ZAI.create();

    // Create chat completion
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: fullSystemPrompt,
        },
        {
          role: 'user',
          content: message,
        },
      ],
      temperature: 0.7,
      max_tokens: 1000,
    });

    // Extract the response
    const response = completion.choices[0]?.message?.content || 
      'Desculpe, não consegui processar sua mensagem no momento. Por favor, tente novamente.';

    // Salvar a conversa no banco de dados
    try {
      await conversationalMemoryService.saveConversation(
        finalSessionId,
        message,
        response,
        ['user_message', 'ai_response']
      );
    } catch (error) {
      console.error('Erro ao salvar conversa:', error);
      // Continuar mesmo se não conseguir salvar
    }

    return NextResponse.json({ 
      response,
      sessionId: finalSessionId,
      context: {
        hasUserProfile: !!context.userProfile,
        hasHistory: context.history.length > 0,
        hasRelevantMemories: context.relevantMemories.length > 0,
      }
    });
  } catch (error) {
    console.error('Erro no chatbot:', error);
    return NextResponse.json(
      { 
        response: 'Desculpe, estou com dificuldades para responder no momento. Por favor, tente novamente mais tarde ou entre em contato pelo WhatsApp: 11 96608-2670' 
      },
      { status: 500 }
    );
  }
}