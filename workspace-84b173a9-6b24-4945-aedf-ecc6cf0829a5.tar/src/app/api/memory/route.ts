import { NextRequest, NextResponse } from 'next/server';
import { conversationalMemoryService } from '@/lib/conversational-memory-service';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get('sessionId');
    const userId = searchParams.get('userId');

    if (!sessionId) {
      return NextResponse.json(
        { success: false, error: 'SessionId não fornecido' },
        { status: 400 }
      );
    }

    const context = await conversationalMemoryService.getConversationContext(sessionId);

    return NextResponse.json({
      success: true,
      data: context,
    });
  } catch (error) {
    console.error('Erro ao buscar contexto da memória:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao buscar contexto da memória' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { action, sessionId, userId, data } = await request.json();

    switch (action) {
      case 'initialize_session':
        return await initializeSession(sessionId, userId);
      case 'end_session':
        return await endSession(sessionId);
      case 'search_memories':
        return await searchMemories(userId, data?.query);
      case 'update_user_profile':
        return await updateUserProfile(userId, data?.updates);
      case 'get_conversation_summary':
        return await getConversationSummary(sessionId);
      default:
        return NextResponse.json(
          { success: false, error: 'Ação não reconhecida' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('Erro no serviço de memória:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

async function initializeSession(sessionId: string, userId?: string) {
  try {
    const context = await conversationalMemoryService.initializeSession(sessionId, userId);
    
    return NextResponse.json({
      success: true,
      data: context,
    });
  } catch (error) {
    console.error('Erro ao inicializar sessão:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao inicializar sessão' },
      { status: 500 }
    );
  }
}

async function endSession(sessionId: string) {
  try {
    await conversationalMemoryService.endSession(sessionId);
    
    return NextResponse.json({
      success: true,
      message: 'Sessão encerrada com sucesso',
    });
  } catch (error) {
    console.error('Erro ao encerrar sessão:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao encerrar sessão' },
      { status: 500 }
    );
  }
}

async function searchMemories(userId: string, query?: string) {
  try {
    if (!userId || !query) {
      return NextResponse.json(
        { success: false, error: 'UserId e query são obrigatórios' },
        { status: 400 }
      );
    }

    const memories = await conversationalMemoryService.searchRelevantInformation(userId, query);
    
    return NextResponse.json({
      success: true,
      data: memories,
    });
  } catch (error) {
    console.error('Erro ao buscar memórias:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao buscar memórias' },
      { status: 500 }
    );
  }
}

async function updateUserProfile(userId: string, updates?: any) {
  try {
    if (!userId || !updates) {
      return NextResponse.json(
        { success: false, error: 'UserId e updates são obrigatórios' },
        { status: 400 }
      );
    }

    const updatedProfile = await conversationalMemoryService.updateUserProfile(userId, updates);
    
    return NextResponse.json({
      success: true,
      data: updatedProfile,
    });
  } catch (error) {
    console.error('Erro ao atualizar perfil do usuário:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao atualizar perfil do usuário' },
      { status: 500 }
    );
  }
}

async function getConversationSummary(sessionId: string) {
  try {
    if (!sessionId) {
      return NextResponse.json(
        { success: false, error: 'SessionId é obrigatório' },
        { status: 400 }
      );
    }

    const summary = await conversationalMemoryService.supabaseMemoryService.generateConversationSummary(sessionId);
    
    return NextResponse.json({
      success: true,
      data: { summary },
    });
  } catch (error) {
    console.error('Erro ao gerar resumo da conversa:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao gerar resumo da conversa' },
      { status: 500 }
    );
  }
}