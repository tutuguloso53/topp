import { NextRequest, NextResponse } from 'next/server';
import { calendlyBookingService } from '@/lib/calendly-booking-service';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const date = searchParams.get('date');

    if (!date) {
      return NextResponse.json({ 
        error: 'Parâmetro "date" é obrigatório. Use o formato YYYY-MM-DD' 
      }, { status: 400 });
    }

    console.log('Testando sistema de agendamento para a data:', date);

    // Validar a data
    const validation = calendlyBookingService.validateDate(date);
    if (!validation.isValid) {
      return NextResponse.json({ 
        error: validation.error || 'Data inválida' 
      }, { status: 400 });
    }

    // Buscar horários disponíveis
    const availableSlots = await calendlyBookingService.getAvailableSlots(validation.formattedDate!);
    
    return NextResponse.json({ 
      success: true, 
      date: validation.formattedDate,
      availableSlots,
      message: availableSlots.length > 0 
        ? `Encontrados ${availableSlots.length} horários disponíveis` 
        : 'Nenhum horário disponível para esta data'
    });
  } catch (error) {
    console.error('Erro no teste de agendamento:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Erro desconhecido' 
      },
      { status: 500 }
    );
  }
}