import { NextRequest, NextResponse } from 'next/server';
import { supabaseMemoryService } from '@/lib/supabase-memory-service';

export async function GET(request: NextRequest) {
  try {
    // Testar conexão básica
    const { data, error } = await supabaseMemoryService.supabase
      .from('conversations')
      .select('count')
      .limit(1);

    if (error) {
      console.error('Erro ao testar conexão:', error);
      return NextResponse.json({
        success: false,
        error: 'Erro ao conectar com o banco de dados',
        details: error.message
      }, { status: 500 });
    }

    // Testar criação de sessão
    const testSessionId = `test_${Date.now()}`;
    try {
      await supabaseMemoryService.createSession(testSessionId);
      
      // Limpar sessão de teste
      await supabaseMemoryService.supabase
        .from('conversation_sessions')
        .delete()
        .eq('session_id', testSessionId);

      return NextResponse.json({
        success: true,
        message: 'Conexão com Supabase estabelecida com sucesso!',
        database: {
          connected: true,
          tables: ['conversations', 'user_profiles', 'conversation_sessions']
        }
      });
    } catch (sessionError) {
      console.error('Erro ao criar sessão de teste:', sessionError);
      return NextResponse.json({
        success: false,
        error: 'Erro ao criar sessão de teste',
        details: sessionError instanceof Error ? sessionError.message : 'Erro desconhecido'
      }, { status: 500 });
    }
  } catch (error) {
    console.error('Erro no teste de conexão:', error);
    return NextResponse.json({
      success: false,
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { action } = await request.json();

    switch (action) {
      case 'create_tables':
        return await createTables();
      case 'test_save_memory':
        return await testSaveMemory();
      case 'test_user_profile':
        return await testUserProfile();
      default:
        return NextResponse.json({
          success: false,
          error: 'Ação não reconhecida'
        }, { status: 400 });
    }
  } catch (error) {
    console.error('Erro no POST do teste:', error);
    return NextResponse.json({
      success: false,
      error: 'Erro interno do servidor'
    }, { status: 500 });
  }
}

async function createTables() {
  try {
    // Tentar forçar criação das tabelas
    await supabaseMemoryService.supabase.from('conversations').insert({
      session_id: 'setup_test',
      message: 'test',
      response: 'test',
      timestamp: new Date().toISOString()
    });

    await supabaseMemoryService.supabase.from('user_profiles').insert({
      user_id: 'test_user',
      name: 'Test User'
    });

    await supabaseMemoryService.supabase.from('conversation_sessions').insert({
      session_id: 'setup_test_session',
      status: 'active',
      start_time: new Date().toISOString()
    });

    // Limpar dados de teste
    await supabaseMemoryService.supabase.from('conversations').delete().eq('session_id', 'setup_test');
    await supabaseMemoryService.supabase.from('user_profiles').delete().eq('user_id', 'test_user');
    await supabaseMemoryService.supabase.from('conversation_sessions').delete().eq('session_id', 'setup_test_session');

    return NextResponse.json({
      success: true,
      message: 'Tabelas criadas e testadas com sucesso!'
    });
  } catch (error) {
    console.error('Erro ao criar tabelas:', error);
    return NextResponse.json({
      success: false,
      error: 'Erro ao criar tabelas',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, { status: 500 });
  }
}

async function testSaveMemory() {
  try {
    const testSessionId = `memory_test_${Date.now()}`;
    const testUserId = `user_test_${Date.now()}`;

    // Testar salvar memória
    const memory = await supabaseMemoryService.saveMemory({
      session_id: testSessionId,
      user_id: testUserId,
      message: 'Mensagem de teste',
      response: 'Resposta de teste'
    });

    // Testar buscar histórico
    const history = await supabaseMemoryService.getConversationHistory(testSessionId, 1);

    // Limpar dados de teste
    await supabaseMemoryService.supabase.from('conversations').delete().eq('session_id', testSessionId);

    return NextResponse.json({
      success: true,
      message: 'Teste de memória concluído com sucesso!',
      data: {
        memorySaved: !!memory,
        historyRetrieved: history.length > 0
      }
    });
  } catch (error) {
    console.error('Erro no teste de memória:', error);
    return NextResponse.json({
      success: false,
      error: 'Erro no teste de memória',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, { status: 500 });
  }
}

async function testUserProfile() {
  try {
    const testUserId = `profile_test_${Date.now()}`;

    // Testar criar perfil
    const profile = await supabaseMemoryService.updateUserProfile(testUserId, {
      name: 'Usuário de Teste',
      email: 'teste@example.com',
      phone: '11999999999'
    });

    // Testar buscar perfil
    const retrievedProfile = await supabaseMemoryService.getUserProfile(testUserId);

    // Limpar dados de teste
    await supabaseMemoryService.supabase.from('user_profiles').delete().eq('user_id', testUserId);

    return NextResponse.json({
      success: true,
      message: 'Teste de perfil de usuário concluído com sucesso!',
      data: {
        profileCreated: !!profile,
        profileRetrieved: !!retrievedProfile
      }
    });
  } catch (error) {
    console.error('Erro no teste de perfil:', error);
    return NextResponse.json({
      success: false,
      error: 'Erro no teste de perfil',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, { status: 500 });
  }
}