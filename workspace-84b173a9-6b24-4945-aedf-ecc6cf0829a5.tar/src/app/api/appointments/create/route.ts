import { NextRequest, NextResponse } from 'next/server';
import { AppointmentService, AppointmentData } from '@/lib/appointment-service';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { patientName, patientEmail, patientPhone, appointmentDate, startTime, notes } = body;

    // Validar campos obrigatórios
    if (!patientName || !patientEmail || !patientPhone || !appointmentDate || !startTime) {
      return NextResponse.json(
        {
          success: false,
          error: 'Campos obrigatórios não preenchidos',
        },
        { status: 400 }
      );
    }

    // Converter datas
    const appointmentDateTime = new Date(appointmentDate);
    const startDateTime = new Date(startTime);
    const endDateTime = new Date(startDateTime);
    endDateTime.setHours(startDateTime.getHours() + 1); // Agendamentos de 1 hora

    const appointmentData: AppointmentData = {
      patientName,
      patientEmail,
      patientPhone,
      appointmentDate: appointmentDateTime,
      startTime: startDateTime,
      endTime: endDateTime,
      notes,
    };

    const appointmentService = new AppointmentService();
    const appointment = await appointmentService.createAppointment(appointmentData);

    return NextResponse.json({
      success: true,
      data: {
        id: appointment.id,
        patientName: appointment.patientName,
        patientEmail: appointment.patientEmail,
        appointmentDate: appointment.appointmentDate,
        startTime: appointment.startTime,
        endTime: appointment.endTime,
        status: appointment.status,
      },
    });
  } catch (error) {
    console.error('Erro ao criar agendamento:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Erro ao criar agendamento',
      },
      { status: 500 }
    );
  }
}