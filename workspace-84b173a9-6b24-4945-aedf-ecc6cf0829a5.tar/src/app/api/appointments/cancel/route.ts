import { NextRequest, NextResponse } from 'next/server';
import { AppointmentService } from '@/lib/appointment-service';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { appointmentId } = body;

    if (!appointmentId) {
      return NextResponse.json(
        {
          success: false,
          error: 'ID do agendamento não fornecido',
        },
        { status: 400 }
      );
    }

    const appointmentService = new AppointmentService();
    const result = await appointmentService.cancelAppointment(appointmentId);

    return NextResponse.json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error('Erro ao cancelar agendamento:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Erro ao cancelar agendamento',
      },
      { status: 500 }
    );
  }
}