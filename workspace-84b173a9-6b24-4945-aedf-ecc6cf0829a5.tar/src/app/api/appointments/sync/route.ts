import { NextRequest, NextResponse } from 'next/server';
import { AppointmentService } from '@/lib/appointment-service';

export async function POST(request: NextRequest) {
  try {
    const appointmentService = new AppointmentService();
    const result = await appointmentService.syncWithCalendly();

    return NextResponse.json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error('Erro ao sincronizar com Calendly:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Erro ao sincronizar com Calendly',
      },
      { status: 500 }
    );
  }
}