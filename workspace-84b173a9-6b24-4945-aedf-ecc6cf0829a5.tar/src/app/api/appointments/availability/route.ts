import { NextRequest, NextResponse } from 'next/server';
import { AppointmentService } from '@/lib/appointment-service';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const daysAhead = parseInt(searchParams.get('daysAhead') || '30', 10);

    const appointmentService = new AppointmentService();
    const availableSlots = await appointmentService.getAvailableSlots(daysAhead);

    return NextResponse.json({
      success: true,
      data: availableSlots,
    });
  } catch (error) {
    console.error('Erro ao buscar disponibilidade:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Erro ao buscar disponibilidade de horários',
      },
      { status: 500 }
    );
  }
}