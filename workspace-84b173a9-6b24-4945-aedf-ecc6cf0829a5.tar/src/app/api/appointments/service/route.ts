import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { action, data } = await request.json();

    switch (action) {
      case 'check_availability':
        return await checkAvailability(data);
      case 'create_appointment':
        return await createAppointment(data);
      case 'get_patient_appointments':
        return await getPatientAppointments(data);
      case 'cancel_appointment':
        return await cancelAppointment(data);
      default:
        return NextResponse.json(
          { success: false, error: 'Ação não reconhecida' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('Erro no serviço de agendamento:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

async function checkAvailability(data: any) {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ''}/api/appointments/availability?daysAhead=${data.daysAhead || 30}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Erro ao verificar disponibilidade');
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Erro ao verificar disponibilidade:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao verificar disponibilidade' },
      { status: 500 }
    );
  }
}

async function createAppointment(data: any) {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ''}/api/appointments/create`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error('Erro ao criar agendamento');
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Erro ao criar agendamento:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao criar agendamento' },
      { status: 500 }
    );
  }
}

async function getPatientAppointments(data: any) {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ''}/api/appointments/patient?email=${encodeURIComponent(data.email)}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Erro ao buscar agendamentos do paciente');
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Erro ao buscar agendamentos do paciente:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao buscar agendamentos do paciente' },
      { status: 500 }
    );
  }
}

async function cancelAppointment(data: any) {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ''}/api/appointments/cancel`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error('Erro ao cancelar agendamento');
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Erro ao cancelar agendamento:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao cancelar agendamento' },
      { status: 500 }
    );
  }
}