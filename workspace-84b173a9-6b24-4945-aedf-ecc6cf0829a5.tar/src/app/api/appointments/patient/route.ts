import { NextRequest, NextResponse } from 'next/server';
import { AppointmentService } from '@/lib/appointment-service';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');

    if (!email) {
      return NextResponse.json(
        {
          success: false,
          error: 'Email não fornecido',
        },
        { status: 400 }
      );
    }

    const appointmentService = new AppointmentService();
    const appointments = await appointmentService.getAppointmentsByPatient(email);

    return NextResponse.json({
      success: true,
      data: appointments,
    });
  } catch (error) {
    console.error('Erro ao buscar agendamentos do paciente:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Erro ao buscar agendamentos do paciente',
      },
      { status: 500 }
    );
  }
}