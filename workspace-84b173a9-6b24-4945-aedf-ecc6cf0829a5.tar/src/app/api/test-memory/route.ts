import { NextRequest, NextResponse } from 'next/server';
import { createMemoryService } from '@/lib/memory-service-factory';

export async function GET(request: NextRequest) {
  try {
    const memoryService = createMemoryService();
    
    // Testar operações básicas
    const testSessionId = `test_${Date.now()}`;
    const testUserId = `user_${Date.now()}`;
    
    console.log('Testando serviço de memória...');
    
    // Testar criação de sessão
    try {
      const session = await memoryService.createSession(testSessionId, testUserId, 'Teste');
      console.log('Sessão criada:', session);
    } catch (error) {
      console.error('Erro ao criar sessão:', error);
    }
    
    // Testar salvamento de memória
    try {
      const memory = await memoryService.saveMemory({
        session_id: testSessionId,
        user_id: testUserId,
        message: 'Mensagem de teste',
        response: 'Resposta de teste',
        context_tags: ['test'],
        importance_score: 1.0,
      });
      console.log('Memória salva:', memory);
    } catch (error) {
      console.error('Erro ao salvar memória:', error);
    }
    
    // Testar busca de histórico
    try {
      const history = await memoryService.getConversationHistory(testSessionId, 10);
      console.log('Histórico recuperado:', history);
    } catch (error) {
      console.error('Erro ao buscar histórico:', error);
    }
    
    // Testar perfil de usuário
    try {
      const profile = await memoryService.updateUserProfile(testUserId, {
        name: 'Usuário Teste',
        email: 'teste@example.com',
      });
      console.log('Perfil atualizado:', profile);
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
    }
    
    return NextResponse.json({ 
      success: true, 
      message: 'Teste de memória concluído',
      sessionId: testSessionId,
      userId: testUserId,
    });
  } catch (error) {
    console.error('Erro no teste de memória:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Erro desconhecido' 
      },
      { status: 500 }
    );
  }
}