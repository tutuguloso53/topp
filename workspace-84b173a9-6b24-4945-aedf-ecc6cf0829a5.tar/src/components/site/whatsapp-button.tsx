"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";
import { MessageCircle, Phone, X } from "lucide-react";

export function WhatsAppButton() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 300);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const quickActions = [
    {
      icon: MessageCircle,
      label: "Agendar Consulta",
      href: "#", // Será substituído pelo onClick
      color: "bg-blue-500 hover:bg-blue-600",
      isChatbot: true
    },
    {
      icon: Phone,
      label: "Emergência",
      href: "https://wa.me/5511966082670?text=URGENTE!%20Preciso%20de%20atendimento%20odontológico%20imediato.",
      color: "bg-red-500 hover:bg-red-600"
    }
  ];

  return (
    <>
      {/* Main WhatsApp Button */}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <motion.div
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="relative"
            >
              <motion.button
                onClick={() => setIsExpanded(!isExpanded)}
                className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-full p-4 shadow-2xl transition-all duration-300 relative overflow-hidden group"
              >
                {/* Animated Background */}
                <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-green-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Pulse Animation */}
                <motion.div
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.7, 0.3, 0.7],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="absolute inset-0 bg-green-400 rounded-full"
                />
                
                {/* Icon */}
                <MessageCircle className="h-6 w-6 relative z-10" />
                
                {/* Notification Badge */}
                <motion.div
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full border-2 border-white flex items-center justify-center"
                >
                  <span className="text-xs text-white font-bold">1</span>
                </motion.div>
              </motion.button>

              {/* Quick Actions Menu */}
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 20 }}
                    className="absolute bottom-20 right-0 space-y-3"
                  >
                    {quickActions.map((action, index) => (
                      <motion.div
                        key={action.label}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        {action.isChatbot ? (
                          <button
                            onClick={() => {
                              // Abrir o chatbot
                              const chatButton = document.querySelector('[data-chatbot-button]');
                              if (chatButton instanceof HTMLElement) {
                                chatButton.click();
                              }
                              setIsExpanded(false);
                            }}
                            className={`${action.color} text-white rounded-full p-3 shadow-lg transition-all duration-300 hover:shadow-xl flex items-center gap-2 group`}
                          >
                            <action.icon className="h-5 w-5" />
                            <span className="text-sm font-medium whitespace-nowrap pr-2">
                              {action.label}
                            </span>
                          </button>
                        ) : (
                          <a
                            href={action.href}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`${action.color} text-white rounded-full p-3 shadow-lg transition-all duration-300 hover:shadow-xl flex items-center gap-2 group`}
                          >
                            <action.icon className="h-5 w-5" />
                            <span className="text-sm font-medium whitespace-nowrap pr-2">
                              {action.label}
                            </span>
                          </a>
                        )}
                      </motion.div>
                    ))}
                    
                    {/* Close Button */}
                    <motion.button
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      transition={{ delay: 0.3 }}
                      onClick={() => setIsExpanded(false)}
                      className="bg-gray-600 hover:bg-gray-700 text-white rounded-full p-3 shadow-lg transition-all duration-300"
                    >
                      <X className="h-5 w-5" />
                    </motion.button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Action Buttons */}
      <AnimatePresence>
        {isVisible && !isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 left-6 z-40 space-y-3"
          >
            {/* Emergency Button */}
            <motion.a
              href="https://wa.me/5511966082670?text=URGENTE!%20Preciso%20de%20atendimento%20odontológico%20imediato."
              target="_blank"
              rel="noopener noreferrer"
              className="bg-red-500 hover:bg-red-600 text-white rounded-full p-3 shadow-lg flex items-center gap-2 group"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Phone className="h-5 w-5" />
              <span className="text-sm font-medium hidden sm:block">Emergência</span>
            </motion.a>

            {/* Call Button */}
            <motion.a
              href="tel:1144580177"
              className="bg-blue-500 hover:bg-blue-600 text-white rounded-full p-3 shadow-lg flex items-center gap-2 group"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Phone className="h-5 w-5" />
              <span className="text-sm font-medium hidden sm:block">Ligar</span>
            </motion.a>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}