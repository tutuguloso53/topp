"use client";

import { Shield, Users, Award, Heart, Clock, MapPin } from "lucide-react";

export function DiferenciaisSection() {
  const diferenciais = [
    {
      icon: Shield,
      title: "Ambiente Seguro",
      description: "Climatizado e confortável para sua tranquilidade",
    },
    {
      icon: Users,
      title: "Equipe Especializada",
      description: "Profissionais altamente qualificados e experientes",
    },
    {
      icon: Award,
      title: "Equipamentos Modernos",
      description: "Tecnologia de última geração para melhores resultados",
    },
    {
      icon: Heart,
      title: "Atendimento Humanizado",
      description: "Foco na experiência e bem-estar do paciente",
    },
    {
      icon: Clock,
      title: "Agendamento Rápido",
      description: "100% online via WhatsApp, prático e eficiente",
    },
    {
      icon: MapPin,
      title: "Localização Privilegiada",
      description: "Fácil acesso em Santo André",
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Por Que Escolher a <span className="text-blue-600">Over Implantes</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Nossa clínica combina tecnologia avançada, profissionais especializados e um atendimento humanizado para proporcionar a melhor experiência em saúde bucal.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {diferenciais.map((diferencial, index) => (
            <div
              key={diferencial.title}
              className="bg-gray-50 p-8 rounded-2xl hover:shadow-lg transition-all duration-300 group"
            >
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-6 group-hover:bg-blue-200 transition-colors">
                <diferencial.icon className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                {diferencial.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {diferencial.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}