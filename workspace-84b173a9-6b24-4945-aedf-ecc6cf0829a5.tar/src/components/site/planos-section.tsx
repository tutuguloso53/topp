"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Star, Check, X, Info } from "lucide-react";

export function PlanosSection() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [showContract, setShowContract] = useState(false);

  const planos = [
    {
      id: "basico",
      titulo: "🔵 PLANO BÁSICO",
      preco: "R$ 149,90/mês",
      precoAnual: "R$ 1.798,80",
      fidelidade: "12 meses",
      imagem: "/plano-basico.jpg",
      destaque: false,
      coberturasImediatas: [
        "Avaliações e Raio-X",
        "Limpeza (Profilaxia)"
      ],
      coberturas90Dias: [
        "Extrações Simples",
        "Restaurações"
      ],
      linkPagamento: "https://www.asaas.com/c/nvozxejx8qywed2p"
    },
    {
      id: "plus",
      titulo: "⭐ PLANO PLUS",
      preco: "R$ 199,90/mês",
      precoAnual: "R$ 2.398,80",
      fidelidade: "12 meses",
      imagem: "/plano-plus.jpg",
      destaque: true,
      coberturasImediatas: [
        "Avaliações e Raio-X",
        "Limpeza (Profilaxia)",
        "Extrações Simples",
        "Restaurações (2 por mês)"
      ],
      coberturas30Dias: [
        "Tratamento de Gengiva"
      ],
      coberturas90Dias: [
        "Tratamento de Canal",
        "Clareamento Dental",
        "Manutenção de Aparelho",
        "Coroas e Provisórios"
      ],
      linkPagamento: "https://www.asaas.com/c/dvx01d7ns3o1t6gc"
    },
    {
      id: "pro",
      titulo: "💎 PLANO PRÓ",
      preco: "R$ 289,90/mês",
      precoAnual: "R$ 3.478,80",
      fidelidade: "12 meses",
      imagem: "/plano-pro.jpg",
      destaque: false,
      coberturasImediatas: [
        "Avaliações e Raio-X",
        "Limpeza (Profilaxia)",
        "Extrações Simples",
        "Restaurações (2 por mês)"
      ],
      coberturas30Dias: [
        "Tratamento de Gengiva"
      ],
      coberturas90Dias: [
        "Tratamento de Canal",
        "Clareamento Dental",
        "Manutenção de Aparelho",
        "Coroas e Provisórios",
        "Implante Unitário",
        "Prótese Parcial Removível (PPR)"
      ],
      linkPagamento: "https://www.asaas.com/c/sa2alrkjoe5pyqoz"
    },
    {
      id: "team",
      titulo: "👨‍👩‍👧‍👦 PLANO TEAM (FAMÍLIA)",
      preco: "R$ 589,90/mês",
      precoAnual: "R$ 7.078,80",
      fidelidade: "12 meses",
      imagem: "/plano-team.jpg",
      destaque: false,
      descricao: "Válido para até 4 pessoas. Cobertura completa do PLANO PLUS para todos os membros.",
      coberturasImediatas: [
        "Avaliações e Raio-X",
        "Limpeza (Profilaxia)",
        "Extrações Simples",
        "Restaurações (2 por mês por pessoa)"
      ],
      coberturas30Dias: [
        "Tratamento de Gengiva"
      ],
      coberturas90Dias: [
        "Tratamento de Canal",
        "Clareamento Dental",
        "Manutenção de Aparelho",
        "Coroas e Provisórios"
      ],
      linkPagamento: "https://www.asaas.com/c/hr9qo4s4l6420ly1"
    },
    {
      id: "teste",
      titulo: "PRODUTO TESTE",
      preco: "R$ 5,00",
      precoAnual: "R$ 5,00",
      fidelidade: "Pagamento único",
      imagem: "/plano-teste.jpg",
      destaque: false,
      descricao: "Produto para testar o fluxo de pagamento.",
      linkPagamento: "https://www.asaas.com/c/h5aobl1dx6gmcxry"
    }
  ];

  const contratoText = `Contrato de Prestação de Serviços Odontológicos por Planos de Adesão

IDENTIFICAÇÃO DAS PARTES CONTRATANTES

CONTRATADA: OverImplantes Centro Odontológico SLU, pessoa jurídica de direito privado, inscrita no CNPJ/MF sob o nº 33.482.267/0001-11, com sede na Av. São Paulo 564, Cidade São Jorge, Santo André - SP, 09111-410, neste ato representada por seu responsável legal e/ou técnico, Dr(a). Ester de Oliveira, inscrito(a) no CRO sob o nº 110137.

Contrato de Prestação de Serviços Odontológicos, que se regerá pelas cláusulas seguintes e pelas condições de preço, forma e termo de pagamento descritas no presente.

CLÁUSULA PRIMEIRA - DO OBJETO DO CONTRATO

1.1. O presente contrato tem como objeto a prestação de serviços odontológicos pela CLÍNICA ao PACIENTE, mediante a adesão a um dos planos odontológicos oferecidos, cujas coberturas, carências e valores são previamente estabelecidos e de conhecimento do PACIENTE.

1.2. O PACIENTE declara, neste ato, ter pleno conhecimento e optar pela adesão ao plano denominado:

CLÁUSULA SEGUNDA - DAS COBERTURAS E CARÊNCIAS

2.1. A utilização dos serviços odontológicos cobertos pelo plano escolhido está sujeita aos seguintes prazos de carência, contados a partir da data de assinatura deste contrato e da confirmação do primeiro pagamento:

* LIBERAÇÃO IMEDIATA (Sem Carência): Procedimentos especificados no plano escolhido como de liberação imediata.
* LIBERAÇÃO EM 30 DIAS: Procedimentos especificados no plano escolhido com carência de 30 (trinta) dias.
* LIBERAÇÃO EM 90 DIAS: Demais procedimentos de cobertura do plano escolhido, com carência de 90 (noventa) dias.

2.2. Para o PLANO TEAM (FAMÍLIA), as carências e coberturas são as estabelecidas para o PLANO PLUS, sendo extensivas a até 4 (quatro) membros da família.

2.3. Procedimentos não listados na cobertura do plano escolhido, bem como aqueles que excedam os limites estabelecidos, serão considerados tratamentos particulares e somente serão executados mediante a aprovação de orçamento prévio pelo PACIENTE.

CLÁUSULA TERCEIRA - DOS VALORES E DA FORMA DE PAGAMENTO

3.1. Pela prestação dos serviços objeto deste contrato, o PACIENTE pagará à CLÍNICA os valores mensais, de acordo com o plano escolhido.

3.2. O pagamento da mensalidade deverá ser efetuado até o dia 10 de cada mês.

3.3. O não pagamento da mensalidade na data de vencimento acarretará a incidência de multa de 2% (dois por cento) sobre o valor devido, acrescido de juros de mora de 1% (um por cento) ao mês.

3.4. O atraso no pagamento por período superior a 30 (trinta) dias implicará na suspensão imediata da cobertura do plano até a regularização do débito.

CLÁUSULA QUARTA - DO PRAZO E DA FIDELIDADE

4.1. O presente contrato terá vigência de 12 (doze) meses, contados a partir da data de sua assinatura, com renovação automática por iguais e sucessivos períodos.

4.2. Fica estabelecido um período de fidelidade de 12 (doze) meses, contados da data de adesão.

4.3. Em caso de rescisão do contrato por parte do PACIENTE antes do término do período de fidelidade de 12 meses, incidirá multa correspondente a 30% (trinta por cento) do valor das mensalidades restantes.

CLÁUSULA QUINTA - DAS OBRIGAÇÕES DA CLÍNICA

5.1. Prestar os serviços odontológicos descritos no plano contratado, utilizando materiais de alta qualidade e seguindo as normas técnicas e éticas da odontologia.
5.2. Manter em seus quadros profissionais habilitados e devidamente registrados no Conselho Regional de Odontologia.
5.3. Informar ao PACIENTE de forma clara e transparente sobre todos os procedimentos a serem realizados.

CLÁUSULA SEXTA - DAS OBRIGAÇÕES DO PACIENTE

6.1. Efetuar o pagamento das mensalidades pontualmente, na forma e nos prazos estabelecidos neste contrato.
6.2. Comparecer às consultas e procedimentos agendados.

CLÁUSULA SÉTIMA - DA RESCISÃO

7.1. O presente contrato poderá ser rescindido de pleno direito nas seguintes hipóteses:
    a) Por violação de quaisquer das cláusulas aqui estabelecidas;
    b) Por inadimplência do PACIENTE por período superior a 60 (sessenta) dias;
    c) Por mútuo acordo entre as partes.

CLÁUSULA OITAVA - DO FORO

8.1. Para dirimir quaisquer controvérsias oriundas do presente contrato, as partes elegem o foro da comarca de Santo André/SP.

OverImplantes Centro Odontológico SLU
CNPJ: 33.482.267/0001-11`;

  const handleComprarAgora = (planoId: string) => {
    setSelectedPlan(planoId);
    setShowContract(true);
  };

  const handleAceiteContrato = () => {
    const plano = planos.find(p => p.id === selectedPlan);
    if (plano) {
      window.open(plano.linkPagamento, '_blank');
    }
    setShowContract(false);
    setSelectedPlan(null);
  };

  return (
    <section id="planos" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Nossos <span className="text-blue-600">Planos</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Escolha o plano ideal para você e sua família. Todos os planos incluem atendimento prioritário e acesso aos nossos especialistas.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {planos.filter(p => p.id !== 'teste').map((plano, index) => (
            <div key={plano.id} className={`relative ${plano.destaque ? 'lg:scale-105' : ''}`}>
              {plano.destaque && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                  <Badge className="bg-orange-500 text-white px-4 py-2 text-sm font-medium">
                    <Star className="h-4 w-4 mr-1" />
                    O Mais Recomendado
                  </Badge>
                </div>
              )}
              
              <Card className={`h-full ${plano.destaque ? 'border-orange-500 border-2 shadow-lg' : 'border-gray-200'}`}>
                <CardHeader className="text-center pb-4">
                  <div className="aspect-video bg-gray-200 rounded-lg mb-4 overflow-hidden">
                    <img
                      src={plano.imagem}
                      alt={plano.titulo}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardTitle className="text-xl font-bold text-gray-900">
                    {plano.titulo}
                  </CardTitle>
                  <CardDescription className="text-2xl font-bold text-blue-600">
                    {plano.preco}
                  </CardDescription>
                  <p className="text-sm text-gray-500">
                    Contratação anual • {plano.fidelidade}
                  </p>
                  {plano.descricao && (
                    <p className="text-sm text-gray-600 mt-2">
                      {plano.descricao}
                    </p>
                  )}
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm font-medium text-gray-700">Liberado na hora:</span>
                    </div>
                    <ul className="space-y-1 ml-4">
                      {plano.coberturasImediatas.map((cobertura, idx) => (
                        <li key={idx} className="text-sm text-gray-600 flex items-start gap-2">
                          <Check className="h-3 w-3 text-green-500 mt-0.5 flex-shrink-0" />
                          {cobertura}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {plano.coberturas30Dias && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                        <span className="text-sm font-medium text-gray-700">Em 30 dias:</span>
                      </div>
                      <ul className="space-y-1 ml-4">
                        {plano.coberturas30Dias.map((cobertura, idx) => (
                          <li key={idx} className="text-sm text-gray-600 flex items-start gap-2">
                            <Check className="h-3 w-3 text-yellow-500 mt-0.5 flex-shrink-0" />
                            {cobertura}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm font-medium text-gray-700">Após 90 dias:</span>
                    </div>
                    <ul className="space-y-1 ml-4">
                      {plano.coberturas90Dias.map((cobertura, idx) => (
                        <li key={idx} className="text-sm text-gray-600 flex items-start gap-2">
                          <Check className="h-3 w-3 text-blue-500 mt-0.5 flex-shrink-0" />
                          {cobertura}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Info className="h-4 w-4 mr-2" />
                          Saiba Mais
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>{plano.titulo}</DialogTitle>
                        </DialogHeader>
                        <ScrollArea className="max-h-96">
                          <div className="space-y-4">
                            <div>
                              <h4 className="font-semibold mb-2">Investimento</h4>
                              <p className="text-gray-600">{plano.preco} ({plano.fidelidade})</p>
                              <p className="text-sm text-gray-500">Total anual: {plano.precoAnual}</p>
                            </div>
                            
                            <div>
                              <h4 className="font-semibold mb-2">Coberturas Liberadas na Hora</h4>
                              <ul className="space-y-1">
                                {plano.coberturasImediatas.map((cobertura, idx) => (
                                  <li key={idx} className="text-sm text-gray-600 flex items-start gap-2">
                                    <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                                    {cobertura}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            {plano.coberturas30Dias && (
                              <div>
                                <h4 className="font-semibold mb-2">Coberturas em 30 Dias</h4>
                                <ul className="space-y-1">
                                  {plano.coberturas30Dias.map((cobertura, idx) => (
                                    <li key={idx} className="text-sm text-gray-600 flex items-start gap-2">
                                      <Check className="h-4 w-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                                      {cobertura}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}

                            <div>
                              <h4 className="font-semibold mb-2">Coberturas após 90 Dias</h4>
                              <ul className="space-y-1">
                                {plano.coberturas90Dias.map((cobertura, idx) => (
                                  <li key={idx} className="text-sm text-gray-600 flex items-start gap-2">
                                    <Check className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                                    {cobertura}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            {plano.descricao && (
                              <div>
                                <h4 className="font-semibold mb-2">Descrição Adicional</h4>
                                <p className="text-sm text-gray-600">{plano.descricao}</p>
                              </div>
                            )}
                          </div>
                        </ScrollArea>
                      </DialogContent>
                    </Dialog>

                    <Button 
                      size="sm" 
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      onClick={() => handleComprarAgora(plano.id)}
                    >
                      Compre Agora
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>

        {/* Produto Teste */}
        <div className="max-w-md mx-auto mb-12">
          <Card className="border-dashed border-2 border-gray-300">
            <CardHeader className="text-center">
              <CardTitle className="text-lg text-gray-700">
                {planos.find(p => p.id === 'teste')?.titulo}
              </CardTitle>
              <CardDescription className="text-xl font-bold text-green-600">
                {planos.find(p => p.id === 'teste')?.preco}
              </CardDescription>
              <p className="text-sm text-gray-500">
                {planos.find(p => p.id === 'teste')?.descricao}
              </p>
            </CardHeader>
            <CardContent>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => handleComprarAgora('teste')}
              >
                Testar Pagamento
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Contract Dialog */}
        <Dialog open={showContract} onOpenChange={setShowContract}>
          <DialogContent className="max-w-4xl max-h-[90vh]">
            <DialogHeader>
              <DialogTitle>Termos e Condições do Contrato</DialogTitle>
            </DialogHeader>
            <ScrollArea className="max-h-96 border rounded-md p-4">
              <pre className="text-sm text-gray-600 whitespace-pre-wrap">
                {contratoText}
              </pre>
            </ScrollArea>
            <div className="flex gap-4 justify-end pt-4">
              <Button variant="outline" onClick={() => setShowContract(false)}>
                <X className="h-4 w-4 mr-2" />
                Recusar
              </Button>
              <Button onClick={handleAceiteContrato} className="bg-green-600 hover:bg-green-700">
                Li e Aceito os Termos
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
}