"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Award, Users, Target, Eye, Lightbulb } from "lucide-react";

export function SobreSection() {
  const equipe = [
    {
      nome: "Dra. Ester de Oliveira",
      cargo: "Dentista Responsável",
      cro: "CRO: 110137",
      especialidade: "Implantodontia e Harmonização Facial",
      descricao: "Com mais de 15 anos de experiência, a Dra. Ester é especialista em implantes dentários e harmonização facial. Sua paixão pela odontologia e dedicação aos pacientes faz dela uma referência na região."
    },
    {
      nome: "Dr. Carlos Silva",
      cargo: "Especialista em Ortodontia",
      cro: "CRO: 085432",
      especialidade: "Ortodontia e Ortopedia Facial",
      descricao: "Especialista em correção de mordida e alinhamento dental, o Dr. Carlos utiliza técnicas modernas para garantir resultados eficientes e confortáveis para pacientes de todas as idades."
    },
    {
      nome: "Dra. Ana Santos",
      cargo: "Especialista em Endodontia",
      cro: "CRO: 092156",
      especialidade: "Tratamentos de Canal",
      descricao: "Com mãos habilidosas e grande precisão, a Dra. Ana é especialista em tratamentos de canal, garantindo procedimentos indolores e alta taxa de sucesso."
    },
    {
      nome: "Dr. Roberto Costa",
      cargo: "Especialista em Prótese Dentária",
      cro: "CRO: 078945",
      especialidade: "Próteses Fixas e Removíveis",
      descricao: "Especialista em reabilitação oral, o Dr. Costa cria próteses que combinam estética perfeita com funcionalidade, devolvendo o sorriso e a autoestima dos pacientes."
    }
  ];

  const valores = [
    {
      icon: Heart,
      titulo: "Humanizado",
      descricao: "Atendimento focado no bem-estar e conforto do paciente"
    },
    {
      icon: Award,
      titulo: "Excelência",
      descricao: "Padrão de qualidade superior em todos os procedimentos"
    },
    {
      icon: Users,
      titulo: "Equipe",
      descricao: "Profissionais altamente qualificados e atualizados"
    },
    {
      icon: Target,
      titulo: "Precisão",
      descricao: "Técnicas avançadas e equipamentos de última geração"
    },
    {
      icon: Eye,
      titulo: "Ética",
      descricao: "Transparência e honestidade em todas as etapas do tratamento"
    },
    {
      icon: Lightbulb,
      titulo: "Inovação",
      descricao: "Sempre buscando as melhores soluções em odontologia"
    }
  ];

  return (
    <section id="sobre" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Sobre a <span className="text-blue-600">Over Implantes</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Conheça nossa história, missão e a equipe dedicada que transforma sorrisos todos os dias com excelência e cuidado.
          </p>
        </div>

        {/* Missão, Visão e Valores */}
        <div className="grid lg:grid-cols-3 gap-8 mb-20">
          <div>
            <Card className="h-full p-8 text-center">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Missão</h3>
                <p className="text-gray-600 leading-relaxed">
                  Proporcionar saúde bucal e qualidade de vida através de tratamentos odontológicos de excelência, 
                  combinando tecnologia avançada com atendimento humanizado e personalizado.
                </p>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="h-full p-8 text-center">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Eye className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Visão</h3>
                <p className="text-gray-600 leading-relaxed">
                  Ser reconhecida como referência em odontologia de alta qualidade na região, 
                  inovando constantemente e transformando a vida de nossos pacientes através de sorrisos saudáveis e bonitos.
                </p>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="h-full p-8 text-center">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Valores</h3>
                <p className="text-gray-600 leading-relaxed">
                  Ética profissional, transparência, respeito ao paciente, busca constante pela excelência, 
                  trabalho em equipe e compromisso com os melhores resultados em saúde bucal.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Nossos Valores */}
        <div className="mb-20">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-12">
            Nossos <span className="text-blue-600">Valores</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {valores.map((valor, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <valor.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">{valor.titulo}</h4>
                    <p className="text-sm text-gray-600 leading-relaxed">{valor.descricao}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Nossa Equipe */}
        <div>
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-12">
            Nossa <span className="text-blue-600">Equipe</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {equipe.map((membro, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <div className="md:flex">
                  <div className="md:w-1/3">
                    <div className="aspect-square bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
                      <div className="text-white text-center">
                        <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-2">
                          <Users className="h-10 w-10" />
                        </div>
                        <p className="text-sm font-medium">Foto</p>
                      </div>
                    </div>
                  </div>
                  <div className="md:w-2/3 p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="text-xl font-bold text-gray-900">{membro.nome}</h4>
                        <p className="text-blue-600 font-medium">{membro.cargo}</p>
                        <Badge variant="secondary" className="mt-1 text-xs">
                          {membro.cro}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm font-medium text-gray-700 mb-2">
                      {membro.especialidade}
                    </p>
                    <p className="text-sm text-gray-600 leading-relaxed">
                      {membro.descricao}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Diferenciais */}
        <div className="mt-20">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-8 md:p-12 text-white">
            <div className="max-w-4xl mx-auto text-center">
              <h3 className="text-3xl font-bold mb-6">
                Por Que Escolher a Over Implantes?
              </h3>
              <div className="grid md:grid-cols-2 gap-8 text-left">
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">Tecnologia de Ponta</h4>
                      <p className="text-sm text-white/80">Equipamentos modernos para diagnósticos precisos e tratamentos eficazes</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">Atendimento Personalizado</h4>
                      <p className="text-sm text-white/80">Cada paciente recebe atenção individualizada e planos de tratamento exclusivos</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">Ambiente Acolhedor</h4>
                      <p className="text-sm text-white/80">Estrutura confortável e climatizada para sua tranquilidade durante o tratamento</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">Localização Privilegiada</h4>
                      <p className="text-sm text-white/80">Fácil acesso em Santo André, com estacionamento conveniente</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}