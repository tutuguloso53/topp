"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  MessageCircle, 
  Phone, 
  MapPin, 
  Mail, 
  Clock, 
  Navigation,
  AlertTriangle,
  Car,
  Train,
  Building,
  Star,
  Heart,
  Shield
} from "lucide-react";

export function ContatoSection() {
  return (
    <section id="contato" className="relative py-20 bg-gradient-to-br from-slate-50 via-white to-blue-50 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-100 to-purple-100 text-blue-800 px-6 py-3 rounded-full text-sm font-medium mb-6"
          >
            <Navigation className="h-5 w-5" />
            Visite Nossa Clínica
          </motion.div>
          
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Nossa <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Localização</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Estamos localizados em Santo André com fácil acesso e estrutura completa para seu conforto.
            Venha nos visitar ou agende sua consulta online.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            {/* Main Contact Card */}
            <Card className="bg-white border-0 shadow-xl overflow-hidden">
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center">
                    <Building className="h-8 w-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">Over Implantes</h3>
                    <p className="text-gray-600">Clínica Odontológica</p>
                  </div>
                </div>

                <div className="space-y-6">
                  {/* WhatsApp */}
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="flex items-start gap-4 p-4 bg-green-50 rounded-xl border border-green-200"
                  >
                    <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <MessageCircle className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 mb-1">WhatsApp</h4>
                      <p className="text-gray-600 text-sm mb-2">Agendamento exclusivo</p>
                      <motion.a
                        href="https://wa.me/5511966082670"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-lg font-bold text-green-600 hover:text-green-700 inline-flex items-center gap-2"
                        whileHover={{ scale: 1.05 }}
                      >
                        11 96608-2670
                        <Star className="h-4 w-4" />
                      </motion.a>
                    </div>
                  </motion.div>

                  {/* Phone */}
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="flex items-start gap-4 p-4 bg-blue-50 rounded-xl border border-blue-200"
                  >
                    <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Phone className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 mb-1">Telefone</h4>
                      <p className="text-gray-600 text-sm mb-2">Dúvidas e suporte</p>
                      <motion.a
                        href="tel:1144580177"
                        className="text-lg font-bold text-blue-600 hover:text-blue-700 inline-flex items-center gap-2"
                        whileHover={{ scale: 1.05 }}
                      >
                        11 4458-0177
                      </motion.a>
                    </div>
                  </motion.div>

                  {/* Address */}
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="flex items-start gap-4 p-4 bg-purple-50 rounded-xl border border-purple-200"
                  >
                    <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <MapPin className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 mb-1">Endereço</h4>
                      <p className="text-gray-600 text-sm mb-2">
                        Av. São Paulo, 564<br />
                        Cidade São Jorge, Santo André - SP, 09111-410
                      </p>
                      <motion.a
                        href="https://www.google.com/maps/dir/?api=1&destination=Av.+São+Paulo+564+Cidade+São+Jorge+Santo+André+SP+09111-410"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-purple-600 hover:text-purple-700 font-medium inline-flex items-center gap-2"
                        whileHover={{ scale: 1.05 }}
                      >
                        <Navigation className="h-4 w-4" />
                        Como Chegar
                      </motion.a>
                    </div>
                  </motion.div>

                  {/* Hours */}
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="flex items-start gap-4 p-4 bg-orange-50 rounded-xl border border-orange-200"
                  >
                    <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Clock className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 mb-1">Horário de Atendimento</h4>
                      <p className="text-gray-600">
                        <span className="font-medium">Segunda a Sexta:</span> 9:00 - 17:00<br />
                        <span className="font-medium">Sábado:</span> Fechado<br />
                        <span className="font-medium">Domingo:</span> Fechado
                      </p>
                    </div>
                  </motion.div>
                </div>

                {/* Quick Actions */}
                <div className="mt-8 grid grid-cols-2 gap-4">
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      size="lg"
                      className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-lg"
                      onClick={() => {
                        // Abrir o chatbot
                        const chatButton = document.querySelector('[data-chatbot-button]');
                        if (chatButton instanceof HTMLElement) {
                          chatButton.click();
                        }
                      }}
                    >
                      <div className="flex items-center justify-center gap-2">
                        <MessageCircle className="h-5 w-5" />
                        Agendar Agora
                      </div>
                    </Button>
                  </motion.div>
                  
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      variant="outline"
                      size="lg"
                      className="w-full border-blue-200 text-blue-600 hover:bg-blue-50"
                      asChild
                    >
                      <a
                        href="https://www.google.com/maps/dir/?api=1&destination=Av.+São+Paulo+564+Cidade+São+Jorge+Santo+André+SP+09111-410"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-2"
                      >
                        <Navigation className="h-5 w-5" />
                        Traçar Rota
                      </a>
                    </Button>
                  </motion.div>
                </div>
              </CardContent>
            </Card>

            {/* Transportation Info */}
            <Card className="bg-white border-0 shadow-lg">
              <CardContent className="p-6">
                <h4 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <Car className="h-5 w-5 text-blue-600" />
                  Como Chegar
                </h4>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center gap-3">
                    <Car className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600">Estacionamento gratuito disponível</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Train className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600">Próximo à estação de metrô</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600">Localização central e de fácil acesso</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Map Section */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <Card className="bg-white border-0 shadow-xl overflow-hidden">
              <CardContent className="p-0">
                <div className="relative h-[600px] rounded-2xl overflow-hidden">
                  {/* Google Maps Embed */}
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3654.7498746378!2d-46.5325!3d-23.6508!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce5ec1b1b1b1b1%3A0x1b1b1b1b1b1b1b1!2sAv.%20S%C3%A3o%20Paulo%2C%20564%20-%20Cidade%20S%C3%A3o%20Jorge%2C%20Santo%20Andr%C3%A9%20-%20SP%2C%2009111-410!5e0!3m2!1spt-BR!2sbr!4v1234567890"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    className="w-full h-full"
                  ></iframe>
                  
                  {/* Map Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent pointer-events-none"></div>
                  
                  {/* Location Marker */}
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <motion.div
                      animate={{ 
                        scale: [1, 1.2, 1],
                        rotate: [0, 5, -5, 0]
                      }}
                      transition={{ 
                        duration: 2, 
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                      className="w-12 h-12 bg-red-500 rounded-full border-4 border-white shadow-lg flex items-center justify-center"
                    >
                      <MapPin className="h-6 w-6 text-white" />
                    </motion.div>
                  </div>

                  {/* Map Info Card */}
                  <div className="absolute bottom-6 left-6 right-6">
                    <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-lg">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-semibold text-gray-900">Over Implantes</h4>
                            <p className="text-sm text-gray-600">Av. São Paulo, 564 - Cidade São Jorge, Santo André - SP, 09111-410</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex items-center gap-1 text-sm text-green-600">
                              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                              Aberto agora
                            </div>
                            <motion.a
                              href="https://www.google.com/maps/dir/?api=1&destination=Av.+São+Paulo+564+Cidade+São+Jorge+Santo+André+SP+09111-410"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                            >
                              Traçar Rota
                            </motion.a>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Emergency Button */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.6 }}
              className="mt-6"
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="inline-block"
              >
                <Button
                  variant="destructive"
                  size="lg"
                  className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white shadow-xl px-8 py-4 text-lg font-semibold"
                  asChild
                >
                  <a
                    href="https://wa.me/5511966082670?text=URGENTE!%20Preciso%20de%20atendimento%20odontológico%20imediato."
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3"
                  >
                    <AlertTriangle className="h-6 w-6" />
                    Emergência Odontológica
                    <span className="text-sm bg-white/20 px-2 py-1 rounded-full">24h</span>
                  </a>
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>

        {/* Trust Badges */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-8 text-white">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div className="flex flex-col items-center gap-3">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                  <Shield className="h-8 w-8 text-white" />
                </div>
                <h4 className="text-xl font-semibold">Ambiente Seguro</h4>
                <p className="text-blue-100 text-sm">Protocolos de esterilização e segurança rigorosos</p>
              </div>
              
              <div className="flex flex-col items-center gap-3">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                  <Heart className="h-8 w-8 text-white" />
                </div>
                <h4 className="text-xl font-semibold">Atendimento Humanizado</h4>
                <p className="text-blue-100 text-sm">Cuidado individualizado e focado no seu bem-estar</p>
              </div>
              
              <div className="flex flex-col items-center gap-3">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                  <Star className="h-8 w-8 text-white" />
                </div>
                <h4 className="text-xl font-semibold">Excelência</h4>
                <p className="text-blue-100 text-sm">Profissionais especializados e tecnologia de ponta</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}