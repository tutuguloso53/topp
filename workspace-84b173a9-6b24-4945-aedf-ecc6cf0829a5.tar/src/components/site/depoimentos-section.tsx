"use client";

import { Star, Quote } from "lucide-react";

export function DepoimentosSection() {
  const depoimentos = [
    {
      nome: "Ana Silva",
      texto: "Atendimento excepcional! A Dra. Ester e toda a equipe são super profissionais e atenciosos. Fizeram meu implante e estou muito satisfeita com o resultado. Ambiente limpo e equipamentos modernos.",
      avaliacao: 5,
      tratamento: "Implante Dentário",
    },
    {
      nome: "Carlos Santos",
      texto: "Melhor clínica odontológica que já frequentei. O agendamento via WhatsApp é muito prático e o atendimento é humanizado. Fiz tratamento de canal e não senti dor nenhuma. Recomendo muito!",
      avaliacao: 5,
      tratamento: "Tratamento de Canal",
    },
    {
      nome: "Mariana Oliveira",
      texto: "A Over Implantes transformou meu sorriso! Fiz clareamento dental e harmonização facial. O resultado foi incrível e toda a equipe me tratou com muito carinho e profissionalismo.",
      avaliacao: 5,
      tratamento: "Clareamento e Harmonização",
    },
    {
      nome: "Roberto Costa",
      texto: "Excelente atendimento desde o agendamento até o pós-tratamento. A clínica é bem localizada, o ambiente é agradável e os preços são justos. Fiz aparelho ortodôntico e estou muito feliz com a evolução.",
      avaliacao: 5,
      tratamento: "Ortodontia",
    },
  ];

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-4 w-4 ${
          index < rating ? "text-yellow-400 fill-current" : "text-gray-300"
        }`}
      />
    ));
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            O Que Nossos <span className="text-blue-600">Pacientes Dizem</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            A satisfação de nossos pacientes é nossa maior recompensa. Veja depoimentos de quem já confia em nosso trabalho.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {depoimentos.map((depoimento, index) => (
            <div
              key={depoimento.nome}
              className="bg-white p-6 rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 relative"
            >
              <Quote className="absolute top-4 right-4 h-8 w-8 text-blue-100" />
              
              <div className="flex items-center gap-1 mb-3">
                {renderStars(depoimento.avaliacao)}
              </div>
              
              <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                {depoimento.texto}
              </p>
              
              <div className="border-t pt-4">
                <h4 className="font-semibold text-gray-900">{depoimento.nome}</h4>
                <p className="text-sm text-blue-600">{depoimento.tratamento}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-800 px-6 py-3 rounded-full">
            <span className="font-medium">4.9/5</span>
            <div className="flex items-center gap-1">
              {renderStars(5)}
            </div>
            <span className="text-sm">Média de avaliação</span>
          </div>
        </div>
      </div>
    </section>
  );
}