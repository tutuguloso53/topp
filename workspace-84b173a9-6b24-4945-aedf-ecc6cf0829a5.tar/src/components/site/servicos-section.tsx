"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ChevronDown, 
  ChevronUp, 
  Star, 
  Clock, 
  Heart, 
  Zap, 
  Shield,
  Sparkles,
  ArrowRight,
  Calendar,
  Timer
} from "lucide-react";

export function ServicosSection() {
  const [expandedService, setExpandedService] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>("todos");

  const categorias = [
    { id: "todos", nome: "Todos os Serviços", icon: Star },
    { id: "cirurgia", nome: "Cirurgia", icon: Shield },
    { id: "estetica", nome: "Estética", icon: Sparkles },
    { id: "preventivo", nome: "Preventivo", icon: Heart },
  ];

  const servicos = [
    {
      id: "implantes",
      titulo: "Implantes Dentários",
      descricao: "Soluções fixas para reposição de dentes",
      descricaoCompleta: "Os implantes dentários são a solução mais moderna e eficaz para substituir dentes perdidos. Utilizamos tecnologia de ponta e materiais biocompatíveis para garantir resultados naturais e duradouros. O procedimento consiste na instalação de um pino de titânio no osso maxilar, que serve como base para a fixação de próteses dentárias.",
      imagem: "/implantes.jpg",
      categoria: "cirurgia",
      beneficios: [
        "Resultado natural e estético",
        "Durabilidade e resistência",
        "Preservação da estrutura óssea",
        "Melhora na função mastigatória",
        "Maior confiança e autoestima"
      ],
      duracao: "3 a 6 meses",
      recuperacao: "7 a 10 dias",
      popularidade: 95,
      destaque: true
    },
    {
      id: "ortodontia",
      titulo: "Aparelhos Ortodônticos",
      descricao: "Tratamentos com aparelhos fixos e móveis",
      descricaoCompleta: "Oferecemos tratamentos ortodônticos completos com aparelhos fixos, móveis e invisíveis. Nossos especialistas corrigem problemas de alinhamento, mordida e espaçamento dos dentes, proporcionando um sorriso harmonioso e funcional. Utilizamos técnicas modernas que reduzem o tempo de tratamento e aumentam o conforto do paciente.",
      imagem: "/ortodontia.jpg",
      categoria: "estetica",
      beneficios: [
        "Alinhamento dental perfeito",
        "Melhora na mastigação e fala",
        "Correção da mordida",
        "Prevenção de problemas articulares",
        "Sorriso mais harmonioso"
      ],
      duracao: "1 a 3 anos",
      recuperacao: "Adaptação de 7 a 15 dias",
      popularidade: 88,
      destaque: false
    },
    {
      id: "endodontia",
      titulo: "Endodontia (Canal)",
      descricao: "Tratamentos de canal modernos e indolores",
      descricaoCompleta: "A endodontia é o tratamento que salva dentes com comprometimento da polpa (nervo). Utilizamos equipamentos modernos como localizadores apicais e sistemas de rotação mecanizada, tornando o procedimento mais rápido, preciso e confortável. Nossa técnica garante alta taxa de sucesso com mínimo desconforto para o paciente.",
      imagem: "/endodontia.jpg",
      categoria: "cirurgia",
      beneficios: [
        "Salvamento do dente natural",
        "Alívio imediato da dor",
        "Procedimento indolor",
        "Alta taxa de sucesso",
        "Prevenção de infecções"
      ],
      duracao: "1 a 2 sessões",
      recuperacao: "1 a 2 dias",
      popularidade: 82,
      destaque: false
    },
    {
      id: "proteses-implantes",
      titulo: "Próteses sobre Implantes",
      descricao: "Reabilitação total e parcial",
      descricaoCompleta: "As próteses sobre implantes são a melhor opção para reabilitação oral completa ou parcial. Confeccionamos próteses fixas e removíveis com materiais de alta qualidade que proporcionam estética natural, conforto e funcionalidade. Cada prótese é personalizada para atender às necessidades específicas do paciente.",
      imagem: "/proteses-implantes.jpg",
      categoria: "cirurgia",
      beneficios: [
        "Estética natural",
        "Máximo conforto",
        "Função mastigatória completa",
        "Durabilidade elevada",
        "Fácil higienização"
      ],
      duracao: "2 a 4 meses",
      recuperacao: "10 a 15 dias",
      popularidade: 90,
      destaque: true
    },
    {
      id: "proteses-removiveis",
      titulo: "Próteses Removíveis",
      descricao: "Soluções práticas para diversos casos",
      descricaoCompleta: "Oferecemos próteses removíveis de alta qualidade para pacientes que necessitam de reabilitação oral. Utilizamos materiais modernos e técnicas avançadas para garantir próteses leves, confortáveis e com excelente adaptação. Nossas próteses são projetadas para restaurar a função mastigatória e a estética do sorriso.",
      imagem: "/proteses-removiveis.jpg",
      categoria: "estetica",
      beneficios: [
        "Opção econômica",
        "Fácil manutenção",
        "Adaptação rápida",
        "Estética melhorada",
        "Função restaurada"
      ],
      duracao: "2 a 4 semanas",
      recuperacao: "5 a 7 dias",
      popularidade: 75,
      destaque: false
    },
    {
      id: "dentistica",
      titulo: "Dentística Restauradora",
      descricao: "Restaurações estéticas e funcionais",
      descricaoCompleta: "A dentística restauradora reúne técnicas para devolver a forma, função e estética dos dentes. Realizamos restaurações em resina composta de última geração, facetas de porcelana e clareamento dental. Cada tratamento é planejado para obter resultados naturais e harmoniosos com o sorriso do paciente.",
      imagem: "/dentistica.jpg",
      categoria: "estetica",
      beneficios: [
        "Resultados naturais",
        "Materiais biocompatíveis",
        "Resistência e durabilidade",
        "Procedimento rápido",
        "Melhora imediata na estética"
      ],
      duracao: "1 a 3 sessões",
      recuperacao: "Imediata",
      popularidade: 85,
      destaque: false
    },
    {
      id: "clinica-geral",
      titulo: "Clínica Geral",
      descricao: "Limpeza, restaurações, check-ups",
      descricaoCompleta: "Nossos serviços de clínica geral incluem limpeza profissional, restaurações, profilaxia e check-ups preventivos. Mantemos a saúde bucal em dia com procedimentos que previnem doenças e detectam problemas precocemente. Nossa abordagem preventiva evita tratamentos complexos e custosos no futuro.",
      imagem: "/clinica-geral.jpg",
      categoria: "preventivo",
      beneficios: [
        "Prevenção de doenças",
        "Diagnóstico precoce",
        "Higiene oral otimizada",
        "Orientação personalizada",
        "Economia a longo prazo"
      ],
      duracao: "30 min a 1 hora",
      recuperacao: "Imediata",
      popularidade: 92,
      destaque: false
    },
    {
      id: "harmonizacao",
      titulo: "Harmonização Facial",
      descricao: "Procedimentos estéticos faciais",
      descricaoCompleta: "A harmonização facial complementa os tratamentos odontológicos, equilibrando o sorriso com os traços faciais. Oferecemos preenchimento labial, aplicação de toxina botulínica e bioestimuladores de colágeno. Todos os procedimentos são realizados por profissionais especializados com foco na naturalidade e segurança.",
      imagem: "/harmonizacao.jpg",
      categoria: "estetica",
      beneficios: [
        "Rosto mais harmonioso",
        "Resultados naturais",
        "Procedimentos seguros",
        "Mínimo tempo de recuperação",
        "Aumento da autoestima"
      ],
      duracao: "30 min a 1 hora",
      recuperacao: "24 a 48 horas",
      popularidade: 78,
      destaque: true
    },
    {
      id: "clareamento",
      titulo: "Clareamento Dental",
      descricao: "Tratamento estético para dentes mais brancos",
      descricaoCompleta: "O clareamento dental é um tratamento seguro e eficaz para remover manchas e escurecimento dos dentes. Utilizamos géis clareadores de última geração e técnicas modernas que garantem resultados uniformes e duradouros. O tratamento é supervisionado por especialistas para garantir a segurança e saúde dos dentes.",
      imagem: "/clareamento.jpg",
      categoria: "estetica",
      beneficios: [
        "Dentes mais brancos",
        "Sorriso rejuvenescido",
        "Procedimento seguro",
        "Resultados rápidos",
        "Aumento da autoconfiança"
      ],
      duracao: "1 a 3 sessões",
      recuperacao: "Imediata",
      popularidade: 87,
      destaque: false
    }
  ];

  const servicosFiltrados = activeCategory === "todos" 
    ? servicos 
    : servicos.filter(servico => servico.categoria === activeCategory);

  const toggleService = (serviceId: string) => {
    setExpandedService(expandedService === serviceId ? null : serviceId);
  };

  return (
    <section id="servicos" className="relative py-20 bg-gradient-to-br from-slate-50 via-white to-blue-50 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse animation-delay-2000"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-100 to-purple-100 text-blue-800 px-6 py-3 rounded-full text-sm font-medium mb-6"
          >
            <Sparkles className="h-5 w-5" />
            Serviços de Excelência
          </motion.div>
          
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Nossos <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Serviços</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Transformamos sorrisos com tecnologia avançada e profissionais especializados. 
            Descubra nossos tratamentos inovadores para sua saúde bucal.
          </p>
        </motion.div>

        {/* Category Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          viewport={{ once: true }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {categorias.map((categoria) => (
            <motion.button
              key={categoria.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveCategory(categoria.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                activeCategory === categoria.id
                  ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
                  : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200"
              }`}
            >
              <categoria.icon className="h-4 w-4" />
              {categoria.nome}
            </motion.button>
          ))}
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {servicosFiltrados.map((servico, index) => (
            <motion.div
              key={servico.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              viewport={{ once: true }}
              className="group"
            >
              <Card className="h-full bg-white border-0 shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden relative">
                {/* Popular Badge */}
                {servico.destaque && (
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5, duration: 0.4 }}
                    className="absolute top-4 left-4 z-10"
                  >
                    <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                      ⭐ Popular
                    </Badge>
                  </motion.div>
                )}

                {/* Popularity Indicator */}
                <div className="absolute top-4 right-4 z-10">
                  <div className="flex items-center gap-1 bg-black/20 backdrop-blur-sm px-2 py-1 rounded-full">
                    <Heart className="h-3 w-3 text-red-400" fill="currentColor" />
                    <span className="text-xs text-white font-medium">{servico.popularidade}%</span>
                  </div>
                </div>

                {/* Image */}
                <div className="relative overflow-hidden">
                  <motion.img
                    src={servico.imagem}
                    alt={servico.titulo}
                    className="w-full h-56 object-cover"
                    whileHover={{ scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                  
                  {/* Category Badge */}
                  <div className="absolute bottom-4 left-4">
                    <Badge variant="secondary" className="bg-white/20 backdrop-blur-sm text-white border-0">
                      {servico.categoria}
                    </Badge>
                  </div>
                </div>

                <CardContent className="p-6">
                  <div className="mb-4">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">
                      {servico.titulo}
                    </h3>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {servico.descricao}
                    </p>
                  </div>

                  {/* Quick Info */}
                  <div className="flex gap-4 mb-4 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{servico.duracao}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Timer className="h-4 w-4" />
                      <span>{servico.recuperacao}</span>
                    </div>
                  </div>

                  {/* Expandable Content */}
                  <AnimatePresence>
                    {expandedService === servico.id && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="space-y-4 mb-4"
                      >
                        <div className="border-t pt-4">
                          <p className="text-sm text-gray-600 leading-relaxed mb-4">
                            {servico.descricaoCompleta}
                          </p>
                          
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                              <Star className="h-4 w-4 text-blue-600" />
                              Benefícios
                            </h4>
                            <div className="grid grid-cols-1 gap-2">
                              {servico.beneficios.map((beneficio, idx) => (
                                <motion.div
                                  key={idx}
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: idx * 0.1 }}
                                  className="flex items-start gap-2"
                                >
                                  <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                                  <span className="text-sm text-gray-600">{beneficio}</span>
                                </motion.div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleService(servico.id)}
                        className="w-full border-blue-200 text-blue-600 hover:bg-blue-50 hover:border-blue-300 transition-all duration-300"
                      >
                        {expandedService === servico.id ? (
                          <>
                            <ChevronUp className="h-4 w-4 mr-2" />
                            Menos Detalhes
                          </>
                        ) : (
                          <>
                            <ChevronDown className="h-4 w-4 mr-2" />
                            Saiba Mais
                          </>
                        )}
                      </Button>
                    </motion.div>

                    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                      <Button
                        size="sm"
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                        onClick={() => {
                          // Abrir o chatbot
                          const chatButton = document.querySelector('[data-chatbot-button]');
                          if (chatButton instanceof HTMLElement) {
                            chatButton.click();
                          }
                        }}
                      >
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          Agendar Avaliação
                          <ArrowRight className="h-4 w-4" />
                        </div>
                      </Button>
                    </motion.div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20"
        >
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden">
            {/* Background Pattern */}
            <div 
              className="absolute inset-0 opacity-10" 
              style={{
                backgroundImage: "url('data:image/svg+xml,%3Csvg width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"%23ffffff\" fill-opacity=\"0.3\"%3E%3Cpath d=\"M20 20c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10zm10 0c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10z\"/%3E%3C/g%3E%3C/svg%3E')"
              }}
            ></div>

            <div className="relative z-10 max-w-4xl mx-auto text-center">
              <h3 className="text-3xl md:text-4xl font-bold mb-6">
                Transforme Seu Sorriso Hoje Mesmo
              </h3>
              <p className="text-xl text-blue-100 mb-8 leading-relaxed">
                Não encontrou o serviço que procura? Nossa equipe está pronta para criar um 
                plano de tratamento personalizado para você.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    size="lg"
                    className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold shadow-xl"
                    onClick={() => {
                      // Abrir o chatbot
                      const chatButton = document.querySelector('[data-chatbot-button]');
                      if (chatButton instanceof HTMLElement) {
                        chatButton.click();
                      }
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <Zap className="h-5 w-5" />
                      Falar com Especialista
                    </div>
                  </Button>
                </motion.div>
                
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="outline"
                    size="lg"
                    className="border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 text-lg font-semibold backdrop-blur-sm"
                    asChild
                  >
                    <a href="#contato" className="flex items-center gap-3">
                      Ver Contato
                      <ArrowRight className="h-5 w-5" />
                    </a>
                  </Button>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}