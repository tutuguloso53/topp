"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Calendar, 
  User, 
  Clock, 
  Heart, 
  Leaf, 
  Shield, 
  Sparkles,
  ArrowRight,
  BookOpen,
  TrendingUp
} from "lucide-react";

export function BlogSection() {
  const artigos = [
    {
      id: 1,
      titulo: "Os Benefícios do Clareamento Dental Profissional",
      resumo: "Descubra como o clareamento profissional pode transformar seu sorriso de forma segura e eficaz.",
      conteudo: "O clareamento dental profissional é um dos tratamentos estéticos mais procurados atualmente. Diferente dos produtos caseiros, o tratamento realizado em consultório oferece resultados mais rápidos, seguros e duradouros. Neste artigo, vamos explicar tudo sobre os benefícios do clareamento profissional e como ele pode transformar seu sorriso.",
      imagem: "/clareamento-blog.jpg",
      autor: "Dra. Ester de Oliveira",
      data: "15 de março de 2024",
      tempoLeitura: "5 min",
      categoria: "estetica",
      popular: true
    },
    {
      id: 2,
      titulo: "Implantes Dentários: A Solução Definitiva para Dentes Perdidos",
      resumo: "Conheça tudo sobre implantes dentários e como eles podem restaurar seu sorriso com naturalidade.",
      conteudo: "Os implantes dentários revolucionaram a odontologia moderna, oferecendo uma solução permanente e estética para substituição de dentes perdidos. Este artigo aborda desde o processo cirúrgico até os cuidados pós-operatórios, mostrando por que os implantes são considerados a melhor opção para reabilitação oral.",
      imagem: "/implantes-blog.jpg",
      autor: "Dr. Carlos Silva",
      data: "10 de março de 2024",
      tempoLeitura: "8 min",
      categoria: "cirurgia",
      popular: true
    },
    {
      id: 3,
      titulo: "Ortodontia em Adultos: É Possível Corrigir a Posição dos Dentes?",
      resumo: "Muitos adultos acreditam que já passou da hora de corrigir a posição dos dentes. Saiba que isso é um mito!",
      conteudo: "A ortodontia não é mais exclusividade de crianças e adolescentes. Cada vez mais adultos buscam tratamento ortodôntico para corrigir problemas de alinhamento e mordida. Modernos aparelhos invisíveis e técnicas avançadas tornaram o tratamento mais confortável e discreto para adultos.",
      imagem: "/ortodontia-blog.jpg",
      autor: "Dra. Ana Costa",
      data: "5 de março de 2024",
      tempoLeitura: "6 min",
      categoria: "estetica",
      popular: false
    },
    {
      id: 4,
      titulo: "Prevenção de Cáries: 5 Dicas Essenciais para Manter Seus Dentes Saudáveis",
      resumo: "A prevenção é sempre o melhor remédio. Aprenda como evitar cáries com hábitos simples do dia a dia.",
      conteudo: "As cáries dentárias ainda são um dos problemas bucais mais comuns na população. Felizmente, a prevenção é simples e pode ser feita com hábitos diários. Neste artigo, apresentamos 5 dicas essenciais para manter seus dentes saudáveis e livres de cáries.",
      imagem: "/prevencao-blog.jpg",
      autor: "Dra. Ester de Oliveira",
      data: "28 de fevereiro de 2024",
      tempoLeitura: "4 min",
      categoria: "preventivo",
      popular: false
    },
    {
      id: 5,
      titulo: "Harmonização Facial: O Que É e Como Complementa o Sorriso",
      resumo: "A harmonização facial vai além dos dentes, criando um equilíbrio entre o sorriso e os traços faciais.",
      conteudo: "A harmonização facial tem se tornado cada vez mais popular como complemento aos tratamentos odontológicos. Este artigo explica como procedimentos como preenchimento labial e aplicação de toxina botulínica podem harmonizar o rosto e valorizar o sorriso.",
      imagem: "/harmonizacao-blog.jpg",
      autor: "Dra. Mariana Santos",
      data: "20 de fevereiro de 2024",
      tempoLeitura: "7 min",
      categoria: "estetica",
      popular: true
    },
    {
      id: 6,
      titulo: "Tratamento de Canal: Mitos e Verdades Sobre o Procedimento",
      resumo: "Muitas pessoas têm medo de tratamento de canal. Desvende os mitos e conheça a verdade sobre este procedimento.",
      conteudo: "O tratamento de canal é um dos procedimentos odontológicos mais temidos pela população, mas grande parte desse medo é baseado em mitos. Neste artigo, vamos desvendar os principais mitos sobre o tratamento de canal e mostrar como a tecnologia moderna tornou o procedimento praticamente indolor.",
      imagem: "/endodontia-blog.jpg",
      autor: "Dr. Roberto Almeida",
      data: "15 de fevereiro de 2024",
      tempoLeitura: "6 min",
      categoria: "cirurgia",
      popular: false
    }
  ];

  const categorias = [
    { id: "todos", nome: "Todos", cor: "bg-gray-500" },
    { id: "estetica", nome: "Estética", cor: "bg-purple-500" },
    { id: "cirurgia", nome: "Cirurgia", cor: "bg-red-500" },
    { id: "preventivo", nome: "Preventivo", cor: "bg-green-500" }
  ];

  return (
    <section id="blog" className="relative py-20 bg-gradient-to-br from-purple-50 via-white to-pink-50 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-pink-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse animation-delay-2000"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-100 to-pink-100 text-purple-800 px-6 py-3 rounded-full text-sm font-medium mb-6"
          >
            <BookOpen className="h-5 w-5" />
            Blog da Saúde Bucal
          </motion.div>
          
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Dicas e <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">Artigos</span> Especializados
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Mantenha-se informado com nossos artigos especializados sobre saúde bucal, 
            tratamentos modernos e dicas para um sorriso saudável.
          </p>
        </motion.div>

        {/* Category Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          viewport={{ once: true }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {categorias.map((categoria) => (
            <motion.button
              key={categoria.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all duration-300 bg-white text-gray-600 hover:bg-gray-100 border border-gray-200"
            >
              <div className={`w-3 h-3 ${categoria.cor} rounded-full`}></div>
              {categoria.nome}
            </motion.button>
          ))}
        </motion.div>

        {/* Featured Article */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <Card className="bg-white border-0 shadow-2xl overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/2">
                <div className="relative h-64 md:h-full">
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 opacity-20"></div>
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      Mais Lido
                    </Badge>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <Badge variant="secondary" className="bg-white/80 backdrop-blur-sm">
                      {artigos[0].categoria}
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="md:w-1/2 p-8">
                <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    <span>{artigos[0].data}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{artigos[0].tempoLeitura}</span>
                  </div>
                </div>
                
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  {artigos[0].titulo}
                </h3>
                
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {artigos[0].resumo}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-500">{artigos[0].autor}</span>
                  </div>
                  
                  <Button 
                    variant="outline" 
                    className="border-purple-200 text-purple-600 hover:bg-purple-50"
                  >
                    Ler Artigo
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {artigos.slice(1).map((artigo, index) => (
            <motion.div
              key={artigo.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              viewport={{ once: true }}
            >
              <Card className="h-full bg-white border-0 shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden group">
                <div className="relative overflow-hidden">
                  <div className="h-48 bg-gradient-to-br from-purple-100 to-pink-100"></div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                  
                  {/* Category Badge */}
                  <div className="absolute bottom-4 left-4">
                    <Badge variant="secondary" className="bg-white/20 backdrop-blur-sm text-white border-0">
                      {artigo.categoria}
                    </Badge>
                  </div>
                  
                  {/* Popular Badge */}
                  {artigo.popular && (
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white">
                        <TrendingUp className="h-3 w-3 mr-1" />
                        Popular
                      </Badge>
                    </div>
                  )}
                </div>

                <CardContent className="p-6">
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      <span>{artigo.data}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{artigo.tempoLeitura}</span>
                    </div>
                  </div>
                  
                  <h3 className="text-lg font-bold text-gray-900 mb-3 group-hover:text-purple-600 transition-colors">
                    {artigo.titulo}
                  </h3>
                  
                  <p className="text-gray-600 text-sm mb-4 leading-relaxed">
                    {artigo.resumo}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-500">{artigo.autor}</span>
                    </div>
                    
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-purple-600 hover:bg-purple-50 p-0 h-auto"
                    >
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20"
        >
          <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div 
                className="absolute top-0 left-0 w-full h-full" 
                style={{
                  backgroundImage: "url('data:image/svg+xml,%3Csvg width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"%23ffffff\" fill-opacity=\"0.3\"%3E%3Cpath d=\"M20 20c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10zm10 0c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10z\"/%3E%3C/g%3E%3C/svg%3E')"
                }}
              ></div>
            </div>

            <div className="relative z-10 max-w-4xl mx-auto text-center">
              <h3 className="text-3xl md:text-4xl font-bold mb-6">
                Fique por Dentro das Novidades
              </h3>
              <p className="text-xl text-purple-100 mb-8 leading-relaxed">
                Receba nossas novidades, dicas exclusivas e artigos especializados 
                diretamente no seu e-mail.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Seu melhor e-mail"
                  className="flex-1 px-6 py-4 rounded-full text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white"
                />
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-4 font-semibold shadow-xl">
                    Inscrever-se
                  </Button>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}