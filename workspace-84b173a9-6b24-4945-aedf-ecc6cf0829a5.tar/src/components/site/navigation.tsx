"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { 
  Menu, 
  Phone, 
  MessageCircle, 
  MapPin, 
  Calendar,
  Star,
  Heart,
  Shield,
  X,
  ChevronDown,
  User,
  Search
} from "lucide-react";

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { name: "Início", href: "/" },
    { name: "Apresentação", href: "#apresentacao" },
    { name: "Serviços", href: "#servicos" },
    { name: "Saúde Bucal", href: "#saude-bucal" },
    { name: "Sobre Nós", href: "#sobre" },
    { name: "Planos", href: "#planos" },
    { name: "Blog", href: "#blog" },
    { name: "Novidades", href: "#novidades" },
    { name: "Contato", href: "#contato" },
  ];

  const servicesDropdown = [
    { name: "Implantes Dentários", href: "#servicos", icon: "🦷" },
    { name: "Ortodontia", href: "#servicos", icon: "🦷" },
    { name: "Harmonização Facial", href: "#servicos", icon: "✨" },
    { name: "Clareamento", href: "#servicos", icon: "⭐" },
  ];

  return (
    <>
      {/* Announcement Bar */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-green-600 to-blue-600 text-white py-2 px-4 text-center text-sm font-medium"
      >
        <div className="container mx-auto flex items-center justify-center gap-2">
          <Star className="h-4 w-4" />
          Agende sua avaliação gratuita pelo WhatsApp: 11 96608-2670
          <Star className="h-4 w-4" />
        </div>
      </motion.div>

      {/* Main Navigation */}
      <header className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        isScrolled 
          ? "bg-white/95 backdrop-blur-md shadow-lg border-b border-gray-200" 
          : "bg-transparent"
      }`}>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 md:h-20 items-center justify-between">
            {/* Logo */}
            <motion.div whileHover={{ scale: 1.05 }}>
              <Link href="/" className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                  <Heart className="h-6 w-6 text-white" />
                </div>
                <div>
                  <div className="text-xl md:text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    Over Implantes
                  </div>
                  <div className="text-xs text-gray-500 hidden sm:block">Odontologia de Excelência</div>
                </div>
              </Link>
            </motion.div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-8">
              {navItems.map((item, index) => (
                <motion.div key={item.name} whileHover={{ scale: 1.05 }}>
                  {item.name === "Serviços" ? (
                    <div className="relative group">
                      <button
                        onMouseEnter={() => setIsServicesOpen(true)}
                        onMouseLeave={() => setIsServicesOpen(false)}
                        className="flex items-center gap-1 text-gray-700 hover:text-blue-600 font-medium transition-colors py-2"
                      >
                        {item.name}
                        <ChevronDown className="h-4 w-4" />
                      </button>
                      
                      {/* Services Dropdown */}
                      <AnimatePresence>
                        {isServicesOpen && (
                          <motion.div
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 10 }}
                            onMouseEnter={() => setIsServicesOpen(true)}
                            onMouseLeave={() => setIsServicesOpen(false)}
                            className="absolute top-full left-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-gray-200 overflow-hidden"
                          >
                            {servicesDropdown.map((service) => (
                              <Link
                                key={service.name}
                                href={service.href}
                                className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors"
                              >
                                <span className="text-lg">{service.icon}</span>
                                <span className="text-gray-700">{service.name}</span>
                              </Link>
                            ))}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ) : (
                    <Link
                      href={item.href}
                      className="text-gray-700 hover:text-blue-600 font-medium transition-colors py-2"
                    >
                      {item.name}
                    </Link>
                  )}
                </motion.div>
              ))}
            </nav>

            {/* Desktop Action Buttons */}
            <div className="hidden md:flex items-center space-x-3">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="border-blue-200 text-blue-600 hover:bg-blue-50"
                  asChild
                >
                  <a href="tel:1144580177" className="flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    <span className="hidden lg:inline">11 4458-0177</span>
                  </a>
                </Button>
              </motion.div>
              
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  size="sm" 
                  className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-lg"
                  onClick={() => {
                    // Abrir o chatbot
                    const chatButton = document.querySelector('[data-chatbot-button]');
                    if (chatButton instanceof HTMLElement) {
                      chatButton.click();
                    }
                  }}
                >
                  <div className="flex items-center gap-2">
                    <MessageCircle className="h-4 w-4" />
                    Agendar Agora
                  </div>
                </Button>
              </motion.div>

              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="border-purple-200 text-purple-600 hover:bg-purple-50"
                  asChild
                >
                  <a 
                    href="#contato" 
                    className="flex items-center gap-2"
                  >
                    <MapPin className="h-4 w-4" />
                    Localização
                  </a>
                </Button>
              </motion.div>
            </div>

            {/* Mobile Menu */}
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                  <Button variant="ghost" size="icon" className="text-gray-700">
                    <Menu className="h-6 w-6" />
                    <span className="sr-only">Abrir menu</span>
                  </Button>
                </motion.div>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px] bg-white">
                <div className="flex flex-col h-full">
                  {/* Header */}
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                        <Heart className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <div className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                          Over Implantes
                        </div>
                        <div className="text-xs text-gray-500">Odontologia de Excelência</div>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                      <X className="h-6 w-6" />
                    </Button>
                  </div>

                  {/* Navigation Items */}
                  <div className="flex-1 overflow-y-auto">
                    <div className="space-y-2">
                      {navItems.map((item) => (
                        <motion.div
                          key={item.name}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <Link
                            href={item.href}
                            className="flex items-center justify-between p-4 rounded-xl hover:bg-gray-50 transition-colors text-gray-700 font-medium"
                            onClick={() => setIsOpen(false)}
                          >
                            {item.name}
                            <ChevronDown className="h-4 w-4 text-gray-400" />
                          </Link>
                        </motion.div>
                      ))}
                    </div>

                    {/* Services Submenu */}
                    <div className="mt-6 p-4 bg-gray-50 rounded-xl">
                      <h4 className="font-semibold text-gray-900 mb-3">Serviços</h4>
                      <div className="space-y-2">
                        {servicesDropdown.map((service) => (
                          <motion.div
                            key={service.name}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                          >
                            <Link
                              href={service.href}
                              className="flex items-center gap-3 p-3 rounded-lg hover:bg-white transition-colors"
                              onClick={() => setIsOpen(false)}
                            >
                              <span className="text-lg">{service.icon}</span>
                              <span className="text-gray-700">{service.name}</span>
                            </Link>
                          </motion.div>
                        ))}
                      </div>
                    </div>

                    {/* Contact Actions */}
                    <div className="mt-8 space-y-3">
                      <h4 className="font-semibold text-gray-900 mb-3">Contato Rápido</h4>
                      
                      <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                        <Button 
                          variant="outline" 
                          className="w-full justify-start border-blue-200 text-blue-600 hover:bg-blue-50"
                          asChild
                        >
                          <a href="tel:1144580177" className="flex items-center gap-3">
                            <Phone className="h-5 w-5" />
                            <div>
                              <div className="font-medium">11 4458-0177</div>
                              <div className="text-xs text-gray-500">Telefone</div>
                            </div>
                          </a>
                        </Button>
                      </motion.div>
                      
                      <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                        <Button 
                          className="w-full justify-start bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white"
                          asChild
                        >
                          <a 
                            href="https://wa.me/5511966082670" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-center gap-3"
                          >
                            <MessageCircle className="h-5 w-5" />
                            <div>
                              <div className="font-medium">WhatsApp</div>
                              <div className="text-xs text-green-100">11 96608-2670</div>
                            </div>
                          </a>
                        </Button>
                      </motion.div>
                      
                      <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                        <Button 
                          variant="outline" 
                          className="w-full justify-start border-purple-200 text-purple-600 hover:bg-purple-50"
                          asChild
                        >
                          <a 
                            href="#contato" 
                            className="flex items-center gap-3"
                          >
                            <MapPin className="h-5 w-5" />
                            <div>
                              <div className="font-medium">Localização</div>
                              <div className="text-xs text-gray-500">Como chegar</div>
                            </div>
                          </a>
                        </Button>
                      </motion.div>
                    </div>

                    {/* Quick Actions */}
                    <div className="mt-8 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl">
                      <h4 className="font-semibold text-gray-900 mb-3">Ações Rápidas</h4>
                      <div className="grid grid-cols-2 gap-2">
                        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="w-full border-gray-200 text-gray-600 hover:bg-white"
                            asChild
                          >
                            <a href="#planos" className="flex items-center gap-1">
                              <Star className="h-4 w-4" />
                              Planos
                            </a>
                          </Button>
                        </motion.div>
                        
                        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="w-full border-gray-200 text-gray-600 hover:bg-white"
                            asChild
                          >
                            <a href="#sobre" className="flex items-center gap-1">
                              <User className="h-4 w-4" />
                              Sobre
                            </a>
                          </Button>
                        </motion.div>
                      </div>
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="mt-8 pt-6 border-t text-center">
                    <div className="text-xs text-gray-500">
                      Horário: Seg-Sex 9h-17h
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      © 2024 Over Implantes
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>
    </>
  );
}