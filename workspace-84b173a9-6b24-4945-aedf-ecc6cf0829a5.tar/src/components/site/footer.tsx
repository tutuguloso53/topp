import Link from "next/link";
import { Phone, MessageCircle, MapPin, Mail, Instagram, Facebook, Clock } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Sobre a Clínica */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-blue-400">Over Implantes</h3>
            <p className="text-gray-300 mb-4">
              Clínica odontológica moderna e elegante em Santo André, especializada em implantes dentários e tratamentos estéticos.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://instagram.com/overimplants"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="https://facebook.com/overimplants"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Contato Rápido */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-blue-400">Contato</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-2 text-gray-300">
                <Phone className="h-4 w-4" />
                <span>11 4458-0177</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-300">
                <MessageCircle className="h-4 w-4" />
                <span>11 96608-2670 (WhatsApp)</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-300">
                <Mail className="h-4 w-4" />
                <span>contato@overimplantes.com.br</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-300">
                <MapPin className="h-4 w-4" />
                <span>Av. São Paulo, 564 - Cidade São Jorge, Santo André - SP, 09111-410</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-300">
                <Clock className="h-4 w-4" />
                <span>Seg-Sex: 9h-17h</span>
              </div>
            </div>
          </div>

          {/* Links Úteis */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-blue-400">Links Úteis</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#servicos" className="text-gray-300 hover:text-white transition-colors">
                  Serviços
                </Link>
              </li>
              <li>
                <Link href="#sobre" className="text-gray-300 hover:text-white transition-colors">
                  Sobre Nós
                </Link>
              </li>
              <li>
                <Link href="#planos" className="text-gray-300 hover:text-white transition-colors">
                  Planos
                </Link>
              </li>
              <li>
                <Link href="#contato" className="text-gray-300 hover:text-white transition-colors">
                  Contato
                </Link>
              </li>
              <li>
                <Link href="/privacidade" className="text-gray-300 hover:text-white transition-colors">
                  Política de Privacidade
                </Link>
              </li>
            </ul>
          </div>

          {/* Convênios */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-blue-400">Convênios</h3>
            <div className="space-y-2">
              <div className="text-gray-300">
                <p className="font-medium text-green-400">Ativos:</p>
                <p>Amil, Dental Plus</p>
              </div>
              <div className="text-gray-300">
                <p className="font-medium text-yellow-400">Em credenciamento:</p>
                <p>SulAmérica, Bradesco, Metlife, Porto Seguro, Intermédica</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 Over Implantes. CNPJ: 33.482.267/0001-11. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}