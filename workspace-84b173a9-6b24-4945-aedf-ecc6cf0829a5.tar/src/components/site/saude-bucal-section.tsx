"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Heart, 
  Shield, 
  Sparkles, 
  Leaf, 
  Sun, 
  Moon,
  Droplet,
  Smile,
  AlertCircle,
  CheckCircle,
  Clock
} from "lucide-react";

export function SaudeBucalSection() {
  const dicas = [
    {
      id: "higiene",
      titulo: "Higiene Bucal Diária",
      icone: Heart,
      cor: "from-red-500 to-pink-500",
      conteudo: [
        "Escove os dentes pelo menos 2 vezes ao dia",
        "Use fio dental diariamente",
        "Troque sua escova de dentes a cada 3 meses",
        "Use creme dental com flúor",
        "Evite escovar com força excessiva"
      ]
    },
    {
      id: "alimentacao",
      titulo: "Alimentação Saudável",
      icone: Leaf,
      cor: "from-green-500 to-emerald-500",
      conteudo: [
        "Limite consumo de açúcares e carboidratos",
        "Evite alimentos ácidos e pegajosos",
        "Prefira frutas, vegetais e alimentos ricos em cálcio",
        "Beba bastante água durante o dia",
        "Evite petiscos entre as refeições"
      ]
    },
    {
      id: "prevencao",
      titulo: "Prevenção de Problemas",
      icone: Shield,
      cor: "from-blue-500 to-indigo-500",
      conteudo: [
        "Visite o dentista regularmente (a cada 6 meses)",
        "Faça limpezas profissionais periódicas",
        "Use protetor bucal durante esportes",
        "Evite fumar e consumir bebidas alcoólicas",
        "Procure tratamento para o bruxismo"
      ]
    },
    {
      id: "tratamentos",
      titulo: "Tratamentos Especiais",
      icone: Sparkles,
      cor: "from-purple-500 to-violet-500",
      conteudo: [
        "Clareamento dental supervisionado por profissional",
        "Uso de aparelhos ortodônticos quando necessário",
        "Tratamento de halitose (mau hálito)",
        "Cuidados com sensibilidade dental",
        "Tratamentos estéticos para harmonizar o sorriso"
      ]
    }
  ];

  const problemas = [
    {
      id: "caries",
      titulo: "Cárie Dentária",
      descricao: "Destruição do tecido dental por bactérias",
      prevencao: ["Higiene bucal adequada", "Uso de flúor", "Visitas regulares ao dentista", "Dieta equilibrada"],
      tratamento: "Restaurações, tratamento de canal ou extração dependendo da gravidade"
    },
    {
      id: "gengivite",
      titulo: "Gengivite",
      descricao: "Inflamação da gengiva causada por placa bacteriana",
      prevencao: ["Higiene oral correta", "Uso de fio dental", "Limpezas profissionais"],
      tratamento: "Limpeza profissional, orientação de higiene e antibióticos se necessário"
    },
    {
      id: "sensibilidade",
      titulo: "Sensibilidade Dental",
      descricao: "Dor ao consumir alimentos quentes, frios ou doces",
      prevencao: ["Evitar escovação vigorosa", "Usar creme dental específico", "Evitar alimentos ácidos"],
      tratamento: "Cremes dentais dessensibilizantes, tratamentos de gel dentina"
    },
    {
      id: "mau-halito",
      titulo: "Mau Hálito (Halitose)",
      descricao: "Odor desagradável na boca",
      prevencao: ["Higiene bucal completa", "Limpeza da língua", "Tratamento de problemas bucais"],
      tratamento: "Identificação da causa, tratamento específico e orientações de higiene"
    }
  ];

  return (
    <section id="saude-bucal" className="relative py-20 bg-gradient-to-br from-green-50 via-white to-blue-50 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-96 h-96 bg-green-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse animation-delay-2000"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-green-100 to-blue-100 text-green-800 px-6 py-3 rounded-full text-sm font-medium mb-6"
          >
            <Leaf className="h-5 w-5" />
            Saúde Bucal Completa
          </motion.div>
          
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Cuide do Seu <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-600 to-blue-600">Sorriso</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Descubra como manter uma saúde bucal impecável com nossas dicas especializadas 
            e informações completas sobre prevenção e tratamento.
          </p>
        </motion.div>

        {/* Tabs Section */}
        <Tabs defaultValue="dicas" className="w-full">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
            <TabsTrigger value="dicas" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              Dicas Essenciais
            </TabsTrigger>
            <TabsTrigger value="problemas" className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4" />
              Problemas Comuns
            </TabsTrigger>
          </TabsList>

          {/* Dicas Tab */}
          <TabsContent value="dicas" className="mt-12">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {dicas.map((dica, index) => (
                <motion.div
                  key={dica.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.6 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full bg-white border-0 shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden group">
                    <CardHeader className="relative overflow-hidden">
                      <div className={`absolute inset-0 bg-gradient-to-r ${dica.cor} opacity-10`}></div>
                      <div className="relative z-10">
                        <dica.icone className={`h-8 w-8 bg-gradient-to-r ${dica.cor} text-white p-2 rounded-lg`} />
                        <CardTitle className="text-lg font-bold text-gray-900 mt-3">
                          {dica.titulo}
                        </CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6 pt-4">
                      <ul className="space-y-3">
                        {dica.conteudo.map((item, idx) => (
                          <motion.li
                            key={idx}
                            initial={{ opacity: 0, x: -10 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.1 }}
                            className="flex items-start gap-2"
                          >
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-gray-600">{item}</span>
                          </motion.li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Problemas Tab */}
          <TabsContent value="problemas" className="mt-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {problemas.map((problema, index) => (
                <motion.div
                  key={problema.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.6 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full bg-white border-0 shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden">
                    <CardHeader className="bg-gradient-to-r from-red-50 to-pink-50 pb-4">
                      <CardTitle className="text-xl font-bold text-gray-900 flex items-center gap-2">
                        <AlertCircle className="h-5 w-5 text-red-500" />
                        {problema.titulo}
                      </CardTitle>
                      <p className="text-sm text-gray-600">
                        {problema.descricao}
                      </p>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                            <Shield className="h-4 w-4 text-blue-500" />
                            Prevenção
                          </h4>
                          <ul className="space-y-2">
                            {problema.prevencao.map((item, idx) => (
                              <li key={idx} className="flex items-start gap-2">
                                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                                <span className="text-sm text-gray-600">{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                            <Clock className="h-4 w-4 text-green-500" />
                            Tratamento
                          </h4>
                          <p className="text-sm text-gray-600">
                            {problema.tratamento}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20"
        >
          <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div 
                className="absolute top-0 left-0 w-full h-full" 
                style={{
                  backgroundImage: "url('data:image/svg+xml,%3Csvg width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"%23ffffff\" fill-opacity=\"0.3\"%3E%3Cpath d=\"M20 20c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10zm10 0c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10z\"/%3E%3C/g%3E%3C/svg%3E')"
                }}
              ></div>
            </div>

            <div className="relative z-10 max-w-4xl mx-auto text-center">
              <h3 className="text-3xl md:text-4xl font-bold mb-6">
                Sua Saúde Bucal é Nossa Prioridade
              </h3>
              <p className="text-xl text-green-100 mb-8 leading-relaxed">
                Não espere problemas aparecerem. Cuide do seu sorriso hoje mesmo com 
                a ajuda de nossos especialistas.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <button
                    onClick={() => {
                      // Abrir o chatbot
                      const chatButton = document.querySelector('[data-chatbot-button]');
                      if (chatButton instanceof HTMLElement) {
                        chatButton.click();
                      }
                    }}
                    className="bg-white text-green-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold shadow-xl rounded-full flex items-center gap-3 transition-all duration-300"
                  >
                    <Smile className="h-5 w-5" />
                    Agendar Consulta
                  </button>
                </motion.div>
                
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <a
                    href="#servicos"
                    className="border-white text-white hover:bg-white hover:text-green-600 px-8 py-4 text-lg font-semibold backdrop-blur-sm rounded-full flex items-center gap-3 transition-all duration-300"
                  >
                    Ver Serviços
                  </a>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}