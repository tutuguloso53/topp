"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Calendar, 
  Gift, 
  Star, 
  Zap, 
  Percent,
  Clock,
  ArrowRight,
  Bell,
  Tag,
  Sparkles
} from "lucide-react";

export function NovidadesSection() {
  const novidades = [
    {
      id: 1,
      tipo: "promocao",
      titulo: "Campanha de Prevenção de Cárie",
      descricao: "Exame clínico completo + limpeza profissional + orientação de higiene por um preço especial!",
      validade: "Válido até 30 de abril de 2024",
      desconto: "30% OFF",
      cor: "from-red-500 to-orange-500",
      popular: true,
      imagem: "/prevencao-campanha.jpg"
    },
    {
      id: 2,
      tipo: "novidade",
      titulo: "Novo Tecnologia de Clareamento",
      descricao: "Chegou em nossa clínica o mais moderno sistema de clareamento dental com resultados em apenas 1 sessão!",
      validade: "Lançamento em março de 2024",
      cor: "from-blue-500 to-indigo-500",
      popular: false,
      imagem: "/clareamento-novo.jpg"
    },
    {
      id: 3,
      tipo: "promocao",
      titulo: "Kit Clareamento em Casa",
      descricao: "Leve seu kit de clareamento profissional para usar em casa com acompanhamento especializado!",
      validade: "Válido até 15 de maio de 2024",
      desconto: "25% OFF",
      cor: "from-purple-500 to-pink-500",
      popular: true,
      imagem: "/clareamento-kit.jpg"
    },
    {
      id: 4,
      tipo: "evento",
      titulo: "Dia do Sorriso Saudável",
      descricao: "Evento gratuito com palestras sobre saúde bucal, avaliações preventivas e sorteios de tratamentos!",
      validade: "25 de março de 2024",
      cor: "from-green-500 to-emerald-500",
      popular: false,
      imagem: "/evento-sorriso.jpg"
    }
  ];

  const planosDestaque = [
    {
      id: "plus",
      titulo: "Plano Plus",
      descricao: "O plano mais completo da clínica com cobertura total!",
      preco: "R$ 199,90/mês",
      destaque: "⭐ O Mais Recomendado",
      cor: "from-blue-600 to-purple-600"
    },
    {
      id: "team",
      titulo: "Plano Team",
      descricao: "Até 4 pessoas com o mesmo benefício do plano Plus!",
      preco: "R$ 589,90/mês",
      destaque: "👨‍👩‍👧‍👦 Família",
      cor: "from-green-600 to-teal-600"
    }
  ];

  return (
    <section id="novidades" className="relative py-20 bg-gradient-to-br from-yellow-50 via-white to-orange-50 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-orange-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse animation-delay-2000"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-yellow-100 to-orange-100 text-orange-800 px-6 py-3 rounded-full text-sm font-medium mb-6"
          >
            <Bell className="h-5 w-5" />
            Novidades e Promoções
          </motion.div>
          
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Ofertas <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-600 to-orange-600">Especiais</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Fique por dentro das nossas promoções exclusivas, novidades e eventos especiais. 
            Aproveite as melhores condições para cuidar do seu sorriso!
          </p>
        </motion.div>

        {/* Novidades Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {novidades.map((novidade, index) => (
            <motion.div
              key={novidade.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              viewport={{ once: true }}
            >
              <Card className="h-full bg-white border-0 shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden group">
                <div className="relative overflow-hidden">
                  <div className={`h-48 bg-gradient-to-br ${novidade.cor} opacity-20`}></div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                  
                  {/* Type Badge */}
                  <div className="absolute top-4 left-4">
                    <Badge 
                      variant="secondary" 
                      className={`${
                        novidade.tipo === 'promocao' ? 'bg-red-500 text-white' :
                        novidade.tipo === 'novidade' ? 'bg-blue-500 text-white' :
                        'bg-green-500 text-white'
                      } backdrop-blur-sm border-0`}
                    >
                      {novidade.tipo === 'promocao' ? <Percent className="h-3 w-3 mr-1" /> :
                       novidade.tipo === 'novidade' ? <Sparkles className="h-3 w-3 mr-1" /> :
                       <Calendar className="h-3 w-3 mr-1" />}
                      {novidade.tipo === 'promocao' ? 'Promoção' :
                       novidade.tipo === 'novidade' ? 'Novidade' : 'Evento'}
                    </Badge>
                  </div>
                  
                  {/* Popular Badge */}
                  {novidade.popular && (
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white">
                        <Star className="h-3 w-3 mr-1" />
                        Popular
                      </Badge>
                    </div>
                  )}
                  
                  {/* Discount Badge */}
                  {novidade.desconto && (
                    <div className="absolute bottom-4 right-4">
                      <Badge className="bg-gradient-to-r from-red-500 to-orange-500 text-white text-lg font-bold">
                        {novidade.desconto}
                      </Badge>
                    </div>
                  )}
                </div>

                <CardContent className="p-6">
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                    <Clock className="h-4 w-4" />
                    <span>{novidade.validade}</span>
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-orange-600 transition-colors">
                    {novidade.titulo}
                  </h3>
                  
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {novidade.descricao}
                  </p>
                  
                  <Button 
                    className="w-full bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white shadow-lg"
                  >
                    {novidade.tipo === 'promocao' ? 'Aproveitar Oferta' :
                     novidade.tipo === 'novidade' ? 'Conhecer Novidade' : 'Inscrever-se'}
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Planos em Destaque */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Planos em <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Destaque</span>
            </h3>
            <p className="text-lg text-gray-600">
              Conheça nossos planos mais populares com condições especiais
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {planosDestaque.map((plano, index) => (
              <motion.div
                key={plano.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2, duration: 0.6 }}
                viewport={{ once: true }}
                className="relative"
              >
                <Card className="h-full bg-white border-0 shadow-2xl overflow-hidden">
                  <div className={`absolute inset-0 bg-gradient-to-br ${plano.cor} opacity-5`}></div>
                  
                  <CardHeader className="relative z-10 text-center pb-4">
                    <Badge className={`bg-gradient-to-r ${plano.cor} text-white text-lg px-4 py-2 mb-4`}>
                      {plano.destaque}
                    </Badge>
                    <CardTitle className="text-2xl font-bold text-gray-900">
                      {plano.titulo}
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent className="relative z-10 p-6 pt-0">
                    <div className="text-center mb-6">
                      <div className="text-3xl font-bold text-gray-900 mb-2">
                        {plano.preco}
                      </div>
                      <p className="text-gray-600">
                        {plano.descricao}
                      </p>
                    </div>
                    
                    <Button 
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg"
                    >
                      Contratar Agora
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="bg-gradient-to-r from-orange-600 to-yellow-600 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div 
              className="absolute top-0 left-0 w-full h-full" 
              style={{
                backgroundImage: "url('data:image/svg+xml,%3Csvg width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"%23ffffff\" fill-opacity=\"0.3\"%3E%3Cpath d=\"M20 20c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10zm10 0c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10z\"/%3E%3C/g%3E%3C/svg%3E')"
              }}
            ></div>
            </div>

            <div className="relative z-10 max-w-4xl mx-auto text-center">
              <h3 className="text-3xl md:text-4xl font-bold mb-6">
                Não Perca Nenhuma Oferta!
              </h3>
              <p className="text-xl text-yellow-100 mb-8 leading-relaxed">
                Cadastre-se para receber nossas promoções exclusivas e novidades 
                diretamente no seu WhatsApp. São condições especiais que você não vai 
                querer perder!
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <a
                    href="https://wa.me/5511966082670?text=Olá!%20Gostaria%20de%20receber%20as%20promoções%20e%20novidades%20da%20clínica."
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-white text-orange-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold shadow-xl rounded-full flex items-center gap-3 transition-all duration-300"
                  >
                    <Zap className="h-5 w-5" />
                    Receber Ofertas
                  </a>
                </motion.div>
                
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <a
                    href="#planos"
                    className="border-white text-white hover:bg-white hover:text-orange-600 px-8 py-4 text-lg font-semibold backdrop-blur-sm rounded-full flex items-center gap-3 transition-all duration-300"
                  >
                    Ver Todos os Planos
                  </a>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}