"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  Star,
  Heart,
  Shield,
  Sparkles,
  ArrowRight,
  Calendar,
  Clock
} from "lucide-react";

export function ApresentacaoSection() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const slides = [
    {
      id: 1,
      titulo: "Bem-vindo à Over Implantes",
      subtitulo: "Sua jornada para um sorriso perfeito começa aqui",
      descricao: "Somos uma clínica odontológica de excelência, dedicada a transformar sorrisos com tecnologia avançada e profissionais altamente qualificados.",
      imagem: "/slide1.jpg",
      cor: "from-blue-600 to-purple-600",
      acao: {
        texto: "Conheça Nossa Clínica",
        link: "#sobre"
      }
    },
    {
      id: 2,
      titulo: "Tecnologia de Ponta",
      subtitulo: "Equipamentos modernos para resultados excepcionais",
      descricao: "Utilizamos a mais nova tecnologia odontológica para garantir tratamentos precisos, rápidos e confortáveis para nossos pacientes.",
      imagem: "/slide2.jpg",
      cor: "from-green-600 to-teal-600",
      acao: {
        texto: "Nossos Serviços",
        link: "#servicos"
      }
    },
    {
      id: 3,
      titulo: "Equipe Especializada",
      subtitulo: "Profissionais dedicados ao seu sorriso",
      descricao: "Nossa equipe é composta por especialistas altamente qualificados, comprometidos em proporcionar o melhor tratamento odontológico.",
      imagem: "/slide3.jpg",
      cor: "from-purple-600 to-pink-600",
      acao: {
        texto: "Conheça a Equipe",
        link: "#sobre"
      }
    },
    {
      id: 4,
      titulo: "Planos Acessíveis",
      subtitulo: "Cuidado odontológico para toda a família",
      descricao: "Oferecemos planos odontológicos completos com condições especiais para você cuidar do seu sorriso sem preocupações.",
      imagem: "/slide4.jpg",
      cor: "from-orange-600 to-red-600",
      acao: {
        texto: "Conheça os Planos",
        link: "#planos"
      }
    },
    {
      id: 5,
      titulo: "Agendamento Fácil",
      subtitulo: "Cuidado odontológico ao seu alcance",
      descricao: "Agende sua consulta de forma rápida e prática através do nosso WhatsApp. Estamos prontos para atender você!",
      imagem: "/slide5.jpg",
      cor: "from-indigo-600 to-blue-600",
      acao: {
        texto: "Agende Agora",
        link: "#chatbot", // Será substituído pelo onClick
        isChatbot: true
      }
    }
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % slides.length);
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, slides.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  return (
    <section id="apresentacao" className="relative py-20 bg-black overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse animation-delay-2000"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-white/10 to-white/20 text-white px-6 py-3 rounded-full text-sm font-medium mb-6 backdrop-blur-sm"
          >
            <Play className="h-5 w-5" />
            Apresentação Interativa
          </motion.div>
          
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
            Conheça Nossa <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">Clínica</span>
          </h2>
          
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Explore nossa clínica através desta apresentação interativa e descubra 
            por que somos a melhor escolha para o seu sorriso.
          </p>
        </motion.div>

        {/* Slideshow Container */}
        <div className={`relative rounded-3xl overflow-hidden shadow-2xl ${
          isFullscreen ? "fixed inset-0 z-50 bg-black" : "max-w-6xl mx-auto"
        }`}>
          {/* Slide */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8 }}
              className="relative h-[600px] md:h-[700px] lg:h-[800px]"
            >
              {/* Background Image */}
              <div className="absolute inset-0">
                <div className={`absolute inset-0 bg-gradient-to-br ${slides[currentSlide].cor} opacity-20`}></div>
                <div className="absolute inset-0 bg-black/40"></div>
              </div>

              {/* Content */}
              <div className="relative z-10 h-full flex items-center justify-center p-8 md:p-12">
                <div className="max-w-4xl mx-auto text-center text-white">
                  <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3, duration: 0.8 }}
                    className="mb-8"
                  >
                    <Badge className="bg-white/20 backdrop-blur-sm text-white border-white/30 mb-6">
                      {slides[currentSlide].subtitulo}
                    </Badge>
                    <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6">
                      {slides[currentSlide].titulo}
                    </h1>
                    <p className="text-xl md:text-2xl text-gray-200 leading-relaxed max-w-3xl mx-auto">
                      {slides[currentSlide].descricao}
                    </p>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6, duration: 0.8 }}
                    className="flex flex-col sm:flex-row gap-4 justify-center"
                  >
                    <Button
                      size="lg"
                      className="bg-white text-gray-900 hover:bg-gray-100 px-8 py-4 text-lg font-semibold shadow-xl"
                      onClick={() => {
                        if (slides[currentSlide].acao.isChatbot) {
                          // Abrir o chatbot
                          const chatButton = document.querySelector('[data-chatbot-button]');
                          if (chatButton instanceof HTMLElement) {
                            chatButton.click();
                          }
                        } else {
                          // Navegar para o link
                          window.location.href = slides[currentSlide].acao.link;
                        }
                      }}
                    >
                      <div className="flex items-center gap-3">
                        {slides[currentSlide].acao.texto}
                        <ArrowRight className="h-5 w-5" />
                      </div>
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="lg"
                      className="border-white text-white hover:bg-white hover:text-gray-900 px-8 py-4 text-lg font-semibold backdrop-blur-sm"
                      onClick={() => goToSlide((currentSlide + 1) % slides.length)}
                    >
                      Próximo Slide
                      <ChevronRight className="h-5 w-5 ml-2" />
                    </Button>
                  </motion.div>
                </div>
              </div>

              {/* Slide Number */}
              <div className="absolute bottom-8 right-8">
                <div className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">
                  <span className="text-white font-medium">
                    {currentSlide + 1} / {slides.length}
                  </span>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation Controls */}
          <div className="absolute inset-0 flex items-center justify-between p-4 md:p-8 pointer-events-none">
            <Button
              variant="ghost"
              size="icon"
              className="bg-white/20 backdrop-blur-sm text-white hover:bg-white/30 pointer-events-auto"
              onClick={prevSlide}
            >
              <ChevronLeft className="h-6 w-6" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              className="bg-white/20 backdrop-blur-sm text-white hover:bg-white/30 pointer-events-auto"
              onClick={nextSlide}
            >
              <ChevronRight className="h-6 w-6" />
            </Button>
          </div>

          {/* Control Panel */}
          <div className="absolute bottom-8 left-8 flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              className="bg-white/20 backdrop-blur-sm text-white hover:bg-white/30"
              onClick={togglePlay}
            >
              {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              className="bg-white/20 backdrop-blur-sm text-white hover:bg-white/30"
              onClick={toggleMute}
            >
              {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              className="bg-white/20 backdrop-blur-sm text-white hover:bg-white/30"
              onClick={toggleFullscreen}
            >
              {isFullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
            </Button>
          </div>

          {/* Slide Indicators */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex gap-2">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentSlide
                    ? "bg-white"
                    : "bg-white/50 hover:bg-white/75"
                }`}
              />
            ))}
          </div>
        </div>

        {/* Slide Thumbnails */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-5 gap-4 max-w-6xl mx-auto">
          {slides.map((slide, index) => (
            <motion.button
              key={slide.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => goToSlide(index)}
              className={`relative rounded-xl overflow-hidden h-32 md:h-40 transition-all duration-300 ${
                index === currentSlide ? "ring-4 ring-white scale-105" : "ring-2 ring-white/50"
              }`}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${slide.cor} opacity-60`}></div>
              <div className="absolute inset-0 bg-black/40"></div>
              <div className="relative z-10 p-4 text-white">
                <div className="text-sm font-medium mb-1">
                  {slide.titulo}
                </div>
                <div className="text-xs text-gray-300">
                  {slide.subtitulo}
                </div>
              </div>
              
              {index === currentSlide && (
                <div className="absolute top-2 right-2">
                  <div className="w-3 h-3 bg-white rounded-full"></div>
                </div>
              )}
            </motion.button>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <h3 className="text-3xl font-bold text-white mb-6">
            Pronto para Transformar Seu Sorriso?
          </h3>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Nossa equipe está preparada para oferecer o melhor tratamento odontológico 
            para você. Agende sua avaliação hoje mesmo!
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <button
                onClick={() => {
                  // Abrir o chatbot
                  const chatButton = document.querySelector('[data-chatbot-button]');
                  if (chatButton instanceof HTMLElement) {
                    chatButton.click();
                  }
                }}
                className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-8 py-4 text-lg font-semibold shadow-xl rounded-full flex items-center gap-3 transition-all duration-300"
              >
                <Calendar className="h-5 w-5" />
                Agendar Avaliação
              </button>
            </motion.div>
            
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <a
                href="#servicos"
                className="border-white text-white hover:bg-white hover:text-gray-900 px-8 py-4 text-lg font-semibold backdrop-blur-sm rounded-full flex items-center gap-3 transition-all duration-300"
              >
                Ver Serviços
                <ArrowRight className="h-5 w-5" />
              </a>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Fullscreen Overlay */}
      {isFullscreen && (
        <div 
          className="fixed inset-0 bg-black z-40"
          onClick={toggleFullscreen}
        />
      )}
    </section>
  );
}